# Contribution and Git hygiene

1. Start a branch for one change: `git switch -c fix/short-description`.
2. Keep generated databases, logs, coverage output, virtual environments, `.env` files and credentials out of Git. Use synthetic examples.
3. Add a regression test for a behavior/security fix. Use temporary storage and controlled clocks. Do not rely on sleeps to simulate urgency deadlines.
4. Run `python tools/check.py`, `node --check static/app.js`, `node tests/test_ui.js` and `python tools/repository_check.py`.
5. Inspect `git diff` and `git diff --check`. Stage only intended files; review `git diff --cached` before committing.
6. Use a small meaningful commit, for example `fix: reject stale handover approval`. Include problem, behavior and validation in the PR description. Never fabricate or backdate commits.
7. For AI-assisted changes, update `PROMPTS.md` with the request, decision, review and measured validation. Never paste real mail, secrets or private source content into AI tools.

The included history was created from the real baseline and the evaluation changes in this session. It does not reconstruct the history of earlier ZIP releases. GitHub CI configuration is provided; remote execution requires pushing the repository and enabling Actions in your organization.
