# AI collaboration and usage record

## Disclosure

This project was developed with ChatGPT/Codex assistance. The assistant generated and revised Python, JavaScript, CSS, tests and documentation. The user supplied the business requirements, technical PRD, reference dashboard HTML, behavior corrections and evaluation criteria. The assistant executed local verification and reviewed failures; no independent human code audit is claimed.

The application currently uses deterministic ACTION/RESOLUTION parsing, keyword scoring, skill matching and exact authorized resolution retrieval. Its labels/confidence are demo heuristics. It does not call an LLM, train a model, send mail or claim measured AI accuracy. Development-time AI usage and application-time AI capability are distinct.

## Request and decision log

| User input | AI contribution and concrete decision | Review/validation |
|---|---|---|
| Problem statement and Technical PRD v1.0 | Built persistent consultant/manager workflows with rules, source references and manager approval | Domain and local HTTP tests |
| Working demo on a short deadline | Used Python standard library and SQLite rather than requiring unconfirmed internal Knox/SSO/model APIs | Dependency-free launch and extracted-package checks |
| Two supplied dashboard HTML files | Applied reference layouts, sample roles and workflow controls | Render checks and syntax checks |
| Checkbox completion; separate status/priority edits; team skill shares; manual transfer | Removed manual fix entry from completion, added pending sent-mail evidence, separate editors and explicit manager transfer | Completion, evidence, correction and transfer regressions |
| Different professional UI; larger text and stronger colors | Redesigned responsive presentation while retaining workflows | UI adapter checks; no screenshot or accessibility certification claimed |
| Automatic balancing example, sample data and popup ingestion | Added one-time leave-coverage proposal and idempotent synthetic import request IDs | Approval ownership, scenario persistence and ingestion tests |
| Manager issue ages; reference skills | Displayed original issue age and expanded employee-owned profile with calculated percentages | Age and profile-edit persistence checks |
| Digithon testing/security/README/Git/AI criteria | Expanded security tests, fixed handover free-text projection, bounded/validated HTTP inputs and storage table identifiers, added quality gates/docs/real Git history | Measured coverage, UI tests and repository checks recorded in docs/VALIDATION.md |

## Review findings and corrections

- Identified free-text task summaries leaking through handover records despite a restricted manager task projection. Applied the same sanitized projection to handovers and added a sentinel regression.
- Found malformed client/identifier values and unexpected task fields could bypass clean validation. Added explicit checks and negative tests.
- Confirmed received mail cannot supply a final resolution, and labeled multi-action replies keep fixes separate.
- Added transaction rollback and SQL identifier/value tests; stable IDs, version checks and employee profile edits remain preserved.
- During test expansion, an oversized upload test observed a client broken pipe when the server correctly rejected the declared body early. Changed the regression to assert the HTTP 413 response from headers without uploading the refused body.
- Corrected coverage attribution for previously compiled relative source paths by compiling the measured modules with absolute filenames before tracing. Coverage includes HTTP worker threads and is explicitly line coverage.

## Working prompts used for this revision

The user's request was to implement unit testing, security, README, Git hygiene and AI usage criteria. The implementation approach was: inspect the current code; find actual gaps; write adversarial/functional regression cases; fix those gaps without changing the UI workflows; run the tests; record measured evidence; and preserve a real baseline plus focused implementation commits.

Representative user constraints retained: managers never receive raw mail, source data is untrusted, replies need review, automatic proposals require manager approval, manual selection is the manager's approval, skills remain employee-owned, and completed tasks await sent-mail evidence rather than an invented fix.

## Data handling and accountability

Only the supplied requirements, reference HTML and synthetic mail examples were used. No credentials, real mailbox history or external Samsung systems were accessed. Before submitting, the project owner should review the code and this disclosure, configure their Git author, and follow their organization's AI-use policy. No benefit hours, model quality or security certification is inferred from passing tests.

## Measured evaluation-edition result

58 Python regressions passed, 8 UI adapter checks passed, and combined backend executable-line coverage was 91.4% against an 80% gate. Git whitespace and heuristic repository checks passed. These are local measured results; remote CI and real-browser validation were not run.

## Password login revision v8

User requested manager and consultant login pages with default passwords. Added role-specific sign-in URLs, named accounts, salted PBKDF2-SHA256 password storage, failed-login cooldown, session rotation/logout and session restoration. Removed the passwordless session route and frontend identity switch. Public evaluation passwords are documented; no enterprise SSO or production credential policy is claimed.

## Expanded manager suggestions v9

User requested 15–20 more balancing entries. Added 18 distinct synthetic task/proposal pairs, preserving eligibility checks and employee edits. The larger sample uses capacity 16, reflected in the dashboard. Tests approve all 19 pending suggestions in sequence and verify ownership, original timestamps, capacity, rejection and restart idempotency.

## Compact presentation v10

User requested only four automatic suggestions, two or three fewer tasks per person, and the reference FICO closure row. Limited the fresh demo to four suggestions and removed two untouched synthetic requests per consultant. Older surplus samples are archived; employee edits and decisions are retained. Added exact-status, closure-tag, highlighting and sample-count regressions.


## v11 — Demo login shortcuts
User requested buttons below the login form to prefill demo accounts. Added six account buttons populated from the existing account endpoint, role switching, accessible selection feedback and responsive card styling. Password verification remains unchanged; button selection never submits credentials. Validated JavaScript syntax, account prefilling and the regression suite.

## v12 — Active task ordering and filters
User requested newest ingested mail first, clickable summary-card filters and sorting by task parameters. Implemented client-side active/high/completed period filtering, resolution-backed completion dates, newest-first ordering and seven sort options for consultant and manager views. Added adapter checks for sorting, filtering and card semantics. No authentication or source-access rules changed.
