# KnoxFlow AI — Digithon evaluation edition

KnoxFlow converts **synthetic Knox-style mail** into consultant tasks, contextual status, resolution logs, and manager workload views. It demonstrates skill-based leave coverage and manager-approved reassignment.

**This is a working local prototype.** Live Knox APIs, enterprise SSO, approved internal LLM inference, encrypted production storage and external mail sending are not implemented. AI behavior in the app uses deterministic extraction and retrieval rules; AI assisted the development of this project. See [PROMPTS.md](PROMPTS.md).

## Demo-login buttons (v11)

Below the sign-in form, choose any of the six demo accounts to prefill its username and default password. Choosing a manager or consultant updates the role automatically. Click **Sign in** to authenticate; selecting a demo button does not submit the form.

## Compact demo update (v10)

A fresh manager dashboard now contains **four automatic balancing suggestions**: the original Sales Portal leave-coverage item plus three access, integration and reporting transfers. Approve/Reject behavior and restart persistence are unchanged. Previous surplus synthetic suggestions on a reused database are archived rather than losing their history.

Two untouched synthetic tasks are removed from each of the five consultants, so both consultant and manager views are less crowded. User-created tasks, completed work and employee-corrected/reassigned sample tasks are preserved.

Sidhant has a highlighted light-green **T-code requirement - FICO** row. Its exact status is **Instructions shared with Ms Lee**, and its task cell displays **Suggested closure**. It remains active until the consultant ticks Complete.

Use a fresh extraction or a new `--db` path for the exact default scenario. Existing user changes are preserved on upgrade, so previously approved suggestions stay approved and edited sample tasks are retained.

## Password sign-in (v8)

Open `/login/consultant` or `/login/manager`, select your named account and enter its default password. Successful sign-in opens that user's dashboard. Sign out before switching accounts. Passwords are salted and hashed with PBKDF2-SHA256 in a separate credentials table; the old passwordless session endpoint is disabled. Five failed attempts trigger a one-minute local cooldown.

| User | Role | Username | Default password |
|---|---|---|---|
| Sidhant Nayak | Consultant | sidhant | Consultant@123 |
| John Doe | Consultant | john | Consultant@123 |
| Matthew Lee | Consultant | matthew | Consultant@123 |
| Sarita Shukla | Consultant | sarita | Consultant@123 |
| Pushpak Kumar | Consultant | pushpak | Consultant@123 |
| Alakh Singh | Manager | alakh | Manager@123 |

These public defaults are for the local synthetic evaluation only. Enterprise SSO, password reset/change and production credential policy remain future work.

## Run locally

Requires Python **3.11 or 3.12**. Runtime uses only the Python standard library: no pip/npm installation, network connection or API key is required.

```bash
python server.py
```

Open **http://127.0.0.1:8000**. On Windows, double-click `start.bat` or use `py -3 server.py`. On macOS/Linux, `bash start.sh` also works. Keep the terminal open; stop with Ctrl+C.

```bash
python server.py --port 8001 --db data/pilot.sqlite3
```

The app creates the database directory itself. A new database gets sample tasks, resolutions, editable reference skills, and an approval-ready leave-coverage suggestion. Existing databases persist changes. To reset, stop the app and use a new `--db` path. Do not delete a database you need.

Local password authentication is enabled; the old unrestricted identity selector has been removed. Public sample credentials are not suitable for real employees. The server binds to loopback only. `--disable-demo-login` denies demo identities and synthetic import routes; it does not add SSO and the UI cannot sign in in that mode.

## Five-minute evaluator walkthrough

1. Start as **Sidhant Nayak**. Edit a task's status message and priority separately. Tick Complete: the task closes immediately without a resolution form. The logger uses authorized sent-mail evidence; missing evidence stays explicitly pending.
2. Open **Work log** and export this month's CSV. Existing sample rows are supplied. Open an active Orion SAP task and request an authorized resolution draft; other client/category combinations may correctly return No match.
3. Sign out and sign in as **Alakh Singh** on the manager login page. Read task ages and workload cards. Under Workload balancing, approve the suggestion to move Matthew Lee's urgent Sales Portal task to Pushpak Kumar. Counts and ownership update immediately.
4. Toggle **Manual workload balancing**. Select an active task in a team card. Its owner becomes grey; other recipients are highlighted. Select the new owner to move it in place. This click is the manager's explicit approval.
5. Click **Ingest sample mail**. Choose a recipient as manager, or use your own mailbox as consultant. Submit a synthetic client request and see its task appear in both views.
6. Explore Skills Profile, leave availability, follow-up acknowledgments and the manager audit trail. Skill percentages describe task share within the team, not proficiency or employee performance.

## Verified local results

See the current measured test and coverage results in docs/VALIDATION.md. See [docs/VALIDATION.md](docs/VALIDATION.md) for module results and verification limits.

## Run the evaluation checks

Python tests and measured line coverage (80% minimum across the four backend modules):

```bash
python tools/check.py
```

The command fails on a failed test or insufficient coverage and writes `build/coverage/summary.json`. Ordinary tests also run without coverage:

```bash
python -m unittest discover -s tests -v
```

For UI adapter tests, install Node.js 22 separately if it is not already available. No Node packages are needed:

```bash
node --check static/app.js
node tests/test_ui.js
```

Git whitespace, generated-file and heuristic secret checks:

```bash
python tools/repository_check.py
```

This last command requires Git metadata. Clone the included history bundle to obtain it, or initialize and stage a source checkout. The scanner is a useful local check, not a comprehensive secret scan or penetration test.

[docs/TESTING.md](docs/TESTING.md) explains scope and limitations. [docs/VALIDATION.md](docs/VALIDATION.md) records the checks executed for this release. The GitHub Actions workflow runs the same checks on Linux and Windows with Python 3.11/3.12 after you push the repository. Those remote jobs have not been run in this environment.

## Evaluation criteria and evidence

| Criterion | Implemented evidence |
|---|---|
| Unit and integration testing | Deterministic domain/storage tests, real local HTTP tests, UI adapter tests, coverage gate; temporary databases and fixed test clocks |
| Security | Server-side role/team/source checks, sanitized manager projections, CSRF/session controls, strict input handling, bounded request body, table allowlist, safe CSV output; [SECURITY.md](SECURITY.md) |
| README and runnability | Offline standard-library runtime, Windows/Linux launchers, setup/troubleshooting, demonstration steps, architecture/input contract |
| Git hygiene | Focused real commits, `.gitignore`, `.gitattributes`, `.editorconfig`, CI checks, no runtime DB/credentials, portable Git history bundle |
| AI usage | [PROMPTS.md](PROMPTS.md) records requests, AI contributions, constraints, review findings, validation and remaining limitations |

## Design and sample input

- `server.py`: loopback HTTP adapter, demo sessions, CSRF, static-asset allowlist, JSON routes.
- `service.py`: extraction rules, access policy, task corrections, completion, retrieval, routing, nudges and synthetic examples.
- `store.py`: bound SQL values, allowlisted table identifiers and atomic SQLite transactions.
- `static/`: responsive consultant/manager dashboards. User-supplied text is HTML-escaped.
- `tests/`: domain, storage, HTTP/security and UI adapter regressions.
- `tools/`: coverage and repository quality gates.

[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) documents APIs and the sample-mail contract. `config.json` controls client tiers, sender weights, capacity and escalation thresholds. Priority is calculated on import; a manual correction persists. Timing uses **elapsed UTC hours**, not business hours. Demo nudges require a manager-triggered check, rather than an external scheduler.

Mail import uses `ACTION[stable-key]: description`. Sent mail can include `RESOLUTION[stable-key]: verified fix`. Unmarked natural-language mail is not model-parsed. Unknown/private/non-work classifications are excluded before extraction. Invalid eligible messages are quarantined without retaining their body. The 60-day import window is enforced. Replaying immutable message IDs does not create duplicate tasks.

## Git history and contribution

The delivery ZIP includes `knoxflow-history.bundle` beside the source folder. Restore the local repository and its real commit history with:

```bash
git clone knoxflow-history.bundle knoxflow-evaluation
cd knoxflow-evaluation
git log --oneline
```

The bundle is generated from the delivered source after validation. No remote is pushed or configured by this task. Commits use a neutral project identity; configure your own Git identity before future work. See [CONTRIBUTING.md](CONTRIBUTING.md).

## Troubleshooting

| Problem | Fix |
|---|---|
| `python` is not recognized | Install Python 3.11/3.12 and enable PATH, or try `py -3` on Windows |
| Port is busy | Start with `--port 8001` and open that URL |
| Old UI/data appears | Stop the old server, start from the new source folder, hard-refresh the page, and use a new `--db` path if a fresh demo is needed |
| No draft match | Confirm an authorized resolution exists for that client and category; missing evidence is an intentional No match |
| New mail creates no task | Use the popup or valid ACTION markers and configured client; inspect import counts |
| Coverage script fails | Read the failing test/coverage summary; do not disable the gate to hide failures |

## Pilot limitations

SQLite is not encrypted, sample passwords are public, and the standard-library server is not internet-facing infrastructure. A production pilot needs approved SSO and source grants, encryption, retention/deletion policy, scheduler/connector retries, model-output validation, observability and deployment review. No employee ranking, autonomous sending, production security certification, benchmark of time savings or real-model accuracy is claimed.

## Dashboard filters and sorting (v12)
Newly ingested tasks appear first by default. Click summary cards to filter active, high-priority or completed work; the manager handover card opens approvals. Clear filter restores all active work. Use Sort by to order by newest, age, priority, requestor, task, status or confidence. Ingestion resets to active work with newest first.
