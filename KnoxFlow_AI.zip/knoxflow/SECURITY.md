# Security model

## Boundary

This build accepts synthetic data on a loopback-only local server. The password login replaces the unrestricted role selector. Public default passwords are supplied only for evaluation. It is not enterprise authentication. No real HR, payroll, appraisal, personal or client mail should be loaded for an evaluation.

## Implemented controls and evidence

| Threat | Control | Regression evidence |
|---|---|---|
| Cross-team or other-owner access | Role/team/current ownership/source checks on service operations | Cross-team, consultant-denial, manager raw-source and handover tests |
| Manager sees raw/free-text mail | Allowlisted task projection, sanitized handover summaries, limited CSV columns | Manager projection and handover sentinel tests |
| Cross-site writes/session guessing | PBKDF2-SHA256 password hashes, failed-login cooldown, random expiring session/CSRF tokens; HttpOnly and SameSite=Strict cookie; Origin/Host/Fetch-Site checks | HTTP auth, CSRF, cookie/header and cross-site tests |
| Untrusted mail instructions | Rule-only extraction; body never executes or selects tools; no send-mail tool | Injection text test; UI escaping test |
| Duplicate or stale action | Stable message/task IDs, closure idempotency, atomic writes, version checks on updates/approvals | Replay, closure, stale approval and rollback tests |
| SQL injection | Values are bound and table identifiers are allowlisted | Bound-value and unknown-table tests |
| Browser script injection | Escaped UI data, scripts served locally, restrictive CSP, frame denial | UI escaping and header tests |
| Spreadsheet formula injection | Formula-like exported values are prefixed safely | CSV test |
| Large/malformed request | 1 MB body limit, exactly one length header, no transfer encoding, read timeout, object JSON and finite-number validation | Oversized, wrong type, malformed/nonfinite JSON tests |
| Unapproved source processing | Explicit work/private flags, 60-day window, source revocation removes derived records | Exclusion, quarantine and private-reclassification tests |
| Credentials/runtime data committed | Ignore rules plus local heuristic secret/generated-file check | `tools/repository_check.py` |

Responses avoid tracebacks and hide the Python server version. Operational audit events contain action identifiers, never mail bodies. Synthetic import request IDs are idempotent. A disabled-demo-login switch denies all `/api/demo/` routes.

## Deliberate limitations

- Local database and HTTP traffic are not encrypted; cookie Secure is not set on loopback HTTP.
- Inline styles are allowed by CSP for generated progress-bar widths; inline scripts are not allowed. This is not a claim of complete XSS prevention.
- Automatic classification is not implemented; the synthetic importer supplies classification metadata.
- No production SSO, authorization grants service, immutable audit sink, rate limiter, persistent session store, full retention/backup deletion or secrets vault is implemented.
- Python's standard-library HTTP server is a demo adapter. The 10-second connection timeout and body limit do not make it a hardened production server.
- The regex scanner covers common key patterns only. It does not replace organization-approved SAST, dependency scanning, dynamic testing or secret detection.
- Tests verify selected adversarial examples, not the absence of all vulnerabilities. UI tests use a DOM adapter, not a real browser.

Before handling real mail: use approved internal infrastructure, SSO-derived identity, source-based access grants, encrypted storage/TLS, formal retention/deletion, production request limits and an organizational security review. The proposed internal LLM integration must validate outputs and retain human approval policies.

## Report a problem

Do not post mail content or credentials in a public issue. Share a minimal synthetic reproduction privately with the project owner through your organization's approved channel. This prototype does not provide a monitored external vulnerability inbox.
