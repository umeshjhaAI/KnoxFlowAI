"""Local demo password authentication. Not enterprise SSO."""
import hashlib
import secrets
import threading
import time
from service import Problem
from store import Store

ACCOUNTS = {'alex':'sidhant','priya':'john','daniel':'matthew','sarita':'sarita','pushpak':'pushpak','morgan':'alakh'}
DEFAULT_PASSWORDS = {'manager':'Manager@123','consultant':'Consultant@123'}
ITERATIONS = 260_000


class Auth:
    def __init__(self, service):
        self.service = service
        self.failures = {}
        self.lock = threading.Lock()

    def accounts(self):
        return [dict(u, username=ACCOUNTS.get(u['id'], u['id'])) for u in self.service.users()]

    def authenticate(self, username, password, role=None):
        if not isinstance(username, str) or not isinstance(password, str) or len(username)>80 or not 1<=len(password)<=200:
            raise Problem(401, 'Invalid username or password')
        username = username.strip().lower()
        with self.lock:
            now = time.monotonic()
            self.failures = {k:v for k,v in self.failures.items() if now-v['start']<60}
            bucket = self.failures.setdefault('local-login', {'start':now,'count':0})
            if bucket['count']>=5:
                raise Problem(429, 'Too many unsuccessful attempts. Try again in one minute.')
            user = next((u for u in self.accounts() if username in (u['username'],u['id'])), None)
            with self.service.store.connect() as db:
                credential = Store.get(db,'credentials',user['id']) if user else None
                if user and not credential:
                    salt = secrets.token_hex(16)
                    digest = hashlib.pbkdf2_hmac('sha256', DEFAULT_PASSWORDS[user['role']].encode(),bytes.fromhex(salt),ITERATIONS).hex()
                    credential = dict(id=user['id'],salt=salt,digest=digest,iterations=ITERATIONS)
                    Store.put(db,'credentials',credential)
            salt = bytes.fromhex(credential['salt']) if credential else b'unknown-user-salt'
            digest = hashlib.pbkdf2_hmac('sha256',password.encode(),salt,ITERATIONS).hex()
            if not user or not secrets.compare_digest(digest,credential['digest']) or (role is not None and role!=user['role']):
                bucket['count']+=1
                raise Problem(401, 'Invalid username or password')
            self.failures.pop('local-login',None)
            return user['id']
