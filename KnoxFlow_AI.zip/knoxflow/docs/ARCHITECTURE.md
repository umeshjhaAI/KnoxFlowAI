# Architecture and input contract

Browser → loopback HTTP adapter → policy/domain service → transactional SQLite storage. Manager responses pass through a restricted projection. Email content is untrusted data; extraction and retrieval use deterministic rules. There is no LLM inference call or tool execution from mail.

## Important records

Users/teams, thread references, messages, versioned tasks, editable skill profiles, confirmed/pending resolution records, handovers, nudges, quarantine metadata and non-content audit events. Stable hashed identifiers deduplicate immutable messages and ACTION keys. Each mutable workflow executes in a SQLite transaction.

## Mail example

```json
{
  "messages": [{
    "mailbox": "alex", "message_id": "example-001", "thread_id": "example-thread",
    "classification": "work", "private": false, "client": "Han River",
    "sender": "client@example.test", "sent_at": "2026-10-27T09:00:00+00:00",
    "direction": "received", "body": "ACTION[report]: Review SAP BI report\nUrgent request."
  }]
}
```

Use a current timestamp within the authorized last 60 days. The UI popup fills it automatically. An authorized sent reply uses the same thread/ACTION key, a new immutable message ID, `direction: "sent"`, and `RESOLUTION[report]: verified fix`. For multiple actions, resolution labels must match. Unlabeled resolution text is accepted only for a single-action message.

## API summary

Routes below require a demo session and writes also require its CSRF token, except explicit demo user/session selection. All supplied actor identities are server-side session values.

| Method | `/api` path | Behavior |
|---|---|---|
| GET | `/auth/accounts` | Named synthetic accounts |
| POST | `/auth/login` | Verify username/password and issue session/CSRF token |
| GET | `/auth/session` | Restore active session CSRF token |
| POST | `/auth/logout` | Invalidate current session |
| POST | `/demo/mail` | Generate synthetic mail; manager may choose same-team consultant |
| GET | `/dashboard` | Role-scoped tasks, skill shares, logs, nudges and handovers |
| POST | `/mail/import` | Own authorized sample-message batch |
| PATCH | `/tasks/{id}` | Own status/priority correction with version; extra fields rejected |
| POST | `/tasks/{id}/complete` | Complete without manual fix; resolution awaits sent evidence if absent |
| POST | `/tasks/{id}/drafts` | Retrieve authorized matching resolution or No match |
| GET | `/tasks/{id}/source` | Authorized source or limited approved handover context |
| POST | `/tasks/{id}/handover` | Propose same-team skilled backup |
| POST | `/handovers/{id}/approve` | Manager approval with version/eligibility recheck |
| POST | `/handovers/{id}/reject` | Persist rejection without moving work |
| POST | `/tasks/{id}/transfer` | Same-team manager-directed transfer, retaining age/history |
| POST | `/policy/tick` | Manager-triggered escalation evaluation |
| POST | `/nudges/{id}/ack` | Recipient acknowledgment |
| PATCH | `/profile` | Employee-owned skills and demo leave state |
| GET | `/resolutions/export?month=YYYY-MM` | Permission-scoped monthly CSV |

The legacy `/tasks/{id}/close` endpoint accepts a confirmed fix for compatibility/testing; current checkbox UI uses `/complete` and never asks users to write a fix. No endpoint sends email.

## Performance and portability

The prototype scans small JSON-backed tables within transactions and recomputes aggregates on request. This is acceptable for synthetic evaluation data, not a measured enterprise-scale design. A production implementation should normalize/index workload queries, paginate history, isolate reads from writes, queue connector/model work and benchmark the agreed pilot load. SQLite JSON rows keep the standard-library build portable; they are not a substitute for approved PostgreSQL infrastructure.
