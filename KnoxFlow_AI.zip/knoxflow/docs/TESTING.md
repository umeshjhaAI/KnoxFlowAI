# Testing strategy

`python tools/check.py` discovers the Python suite and measures executable-line coverage of service.py, server.py, store.py and auth.py, including local HTTP handler threads. It uses the Python standard-library trace engine and its executable-line analysis. The combined gate is 80%. It is line coverage, not branch coverage or a correctness score. A machine-readable result is written to ignored `build/coverage/summary.json`.

| Layer | What is verified |
|---|---|
| Domain | Multiple actions, dedup, corrections, closure, sent-only resolution evidence, routing, leave eligibility, task age, skill shares and scenario idempotency |
| Authorization/security | Cross-team/owner denial, manager projections, sanitized handovers, injection text, source revocation, safe exports, unexpected fields and malformed types |
| Persistence | Atomic rollback, allowlisted identifiers and bound SQL values |
| Local HTTP integration | Real ephemeral loopback server, sessions/CSRF, host/origin controls, JSON handling, static allowlist, routes, headers and role checks |
| UI adapter | Escaping, task age, skill percentages, separate editors, inline manual mode and ingestion popup |

Each Python test uses temporary SQLite storage. Domain time advances through an injected clock. No client data, external service, Knox API or API key is used. Oversized request rejection is tested from headers without uploading a body that the server correctly refuses to read.

The UI checks run in Node's VM with a small DOM adapter: they verify render/action contracts, not CSS layout, focus behavior, browser accessibility or visual appearance. They do not prove a real browser end-to-end flow. Live Knox/SSO/model, load, browser, accessibility and production-infrastructure tests remain future pilot work.

CI declares Linux/Windows and Python 3.11/3.12 jobs. Only the local runtime results in VALIDATION.md have been measured here; do not report configured CI jobs as completed remote runs.
