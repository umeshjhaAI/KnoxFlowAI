# v10 local validation

- 66 Python tests passed; zero failures/errors.
- 9 UI adapter checks passed, including the exact status, closure badge and highlighted row.
- Backend line coverage: 91.59%, above the 80% gate.
- Sample-count tests verify four suggestions and exactly two fewer tasks per consultant. All four proposals can be approved; decisions persist.

| Module | Covered / executable | Coverage |
|---|---|---|
| service.py | 602 / 632 | 95.25% |
| server.py | 170 / 217 | 78.34% |
| store.py | 47 / 48 | 97.92% |
| auth.py | 41 / 42 | 97.62% |

Local synthetic tests only. No live Knox, remote CI, browser screenshot or production security audit is claimed.
