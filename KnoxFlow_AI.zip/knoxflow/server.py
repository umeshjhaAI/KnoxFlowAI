"""Loopback-only demo HTTP adapter. Production requires SSO and a hardened server."""
import argparse
import json
import secrets
import sqlite3
import threading
import time
from http.cookies import SimpleCookie, CookieError
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from service import Service, Problem
from auth import Auth

ROOT = Path(__file__).parent


def make_handler(service, allow_demo_login=True):
    sessions = {}
    auth = Auth(service)
    lock = threading.Lock()

    class Handler(BaseHTTPRequestHandler):
        server_version = 'KnoxFlow'
        sys_version = ''

        def setup(self):
            super().setup()
            self.connection.settimeout(10)

        def log_message(self, *args):
            pass  # Do not log URLs, bodies or credentials.

        def send(self, status, data, content_type='application/json', extra=None):
            payload = json.dumps(data).encode() if content_type == 'application/json' else data
            if isinstance(payload, str):
                payload = payload.encode()
            self.send_response(status)
            for k, v in {'Content-Type': content_type, 'Content-Length': str(len(payload)),
                         'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
                         'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer',
                         'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'; form-action 'self'",
                         'Permissions-Policy': 'camera=(), microphone=(), geolocation=()'}.items():
                self.send_header(k, v)
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(payload)

        def session(self, write=False):
            cookie = SimpleCookie()
            try:
                cookie.load(self.headers.get('Cookie', ''))
                token = cookie['knoxflow'].value
            except (KeyError, ValueError, CookieError):
                raise Problem(401, 'Select a demo identity')
            with lock:
                result = sessions.get(token)
            if not result or result['expires'] < time.time():
                raise Problem(401, 'Demo session expired. Select an identity again.')
            if write and not secrets.compare_digest(self.headers.get('X-CSRF-Token', ''), result['csrf']):
                raise Problem(403, 'Request verification failed')
            return result

        def dispatch(self):
            try:
                expected = f'127.0.0.1:{self.server.server_port}'
                local = f'localhost:{self.server.server_port}'
                if len(self.headers.get_all('Host', [])) != 1 or self.headers.get('Host') not in (expected, local):
                    raise Problem(403, 'This demo accepts localhost requests only')
                origin = self.headers.get('Origin')
                if origin and origin not in (f'http://{expected}', f'http://{local}'):
                    raise Problem(403, 'Cross-origin request denied')
                if self.headers.get('Sec-Fetch-Site') == 'cross-site':
                    raise Problem(403, 'Cross-site request denied')
                parsed = urlparse(self.path)
                path = parsed.path
                query = parse_qs(parsed.query)
                method = self.command
                if (path.startswith('/api/demo/') or path in ('/api/auth/login', '/api/auth/accounts')) and not allow_demo_login:
                    raise Problem(403, 'Demo identity selection is disabled. Enterprise SSO is not configured.')
                if self.headers.get('Transfer-Encoding'):
                    raise Problem(400, 'Transfer-Encoding is not supported')
                if method == 'GET' and path in ('/login', '/login/manager', '/login/consultant', '/login.js'):
                    filename = 'login.js' if path == '/login.js' else 'login.html'
                    return self.send(200, (ROOT / 'static' / filename).read_bytes(), 'text/javascript; charset=utf-8' if filename.endswith('.js') else 'text/html; charset=utf-8')
                if method == 'GET' and path == '/':
                    try:
                        self.session()
                    except Problem:
                        return self.send(302, b'', 'text/plain', {'Location':'/login'})
                if method == 'GET' and path in ('/', '/app.js', '/style.css', '/consultant.css', '/manager.css', '/connected.css', '/design.css'):
                    filename = 'index.html' if path == '/' else path[1:]
                    content_type = 'text/html; charset=utf-8' if path == '/' else 'text/javascript; charset=utf-8' if path.endswith('.js') else 'text/css; charset=utf-8'
                    return self.send(200, (ROOT / 'static' / filename).read_bytes(), content_type)
                body = {}
                if method in ('POST', 'PATCH'):
                    if len(self.headers.get_all('Content-Length', [])) != 1:
                        raise Problem(400, 'Exactly one Content-Length header is required')
                    if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                        raise Problem(415, 'application/json required')
                    try:
                        length = int(self.headers.get('Content-Length', '0'))
                    except ValueError:
                        raise Problem(400, 'Invalid Content-Length')
                    if not 0 <= length <= 1_000_000:
                        raise Problem(413, 'Request is too large')
                    try:
                        raw = self.rfile.read(length)
                        if len(raw) != length:
                            raise ValueError('Incomplete request body')
                        def invalid_constant(value):
                            raise ValueError('Non-finite JSON number')
                        body = json.loads(raw or '{}', parse_constant=invalid_constant)
                    except (ValueError, UnicodeDecodeError, RecursionError):
                        raise Problem(400, 'Invalid JSON')
                    if not isinstance(body, dict):
                        raise Problem(400, 'JSON object required')
                if path in ('/api/demo/session', '/api/demo/users'):
                    raise Problem(410, 'Password sign-in is required. Use /api/auth/login.')
                if path == '/api/auth/accounts' and method == 'GET':
                    return self.send(200, auth.accounts())
                if path == '/api/auth/login' and method == 'POST':
                    uid = auth.authenticate(body.get('username'), body.get('password'), body.get('role'))
                    old_cookie = SimpleCookie()
                    try:
                        old_cookie.load(self.headers.get('Cookie', ''))
                        old_token = old_cookie['knoxflow'].value if 'knoxflow' in old_cookie else None
                    except CookieError:
                        old_token = None
                    token, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
                    with lock:
                        sessions.pop(old_token, None)
                        expired = [k for k, v in sessions.items() if v['expires'] < time.time()]
                        for k in expired:
                            del sessions[k]
                        if len(sessions) >= 100:
                            sessions.pop(next(iter(sessions)))
                        sessions[token] = dict(uid=uid, csrf=csrf, expires=time.time() + 8 * 3600)
                    return self.send(200, dict(csrf=csrf), extra={'Set-Cookie': f'knoxflow={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800'})
                session = self.session(write=method != 'GET')
                uid = session['uid']
                parts = path.strip('/').split('/')
                if path == '/api/auth/session' and method == 'GET':
                    return self.send(200, dict(csrf=session['csrf']))
                if path == '/api/auth/logout' and method == 'POST':
                    with lock:
                        for token in [k for k,v in sessions.items() if v is session]:
                            del sessions[token]
                    return self.send(200, dict(logged_out=True), extra={'Set-Cookie':'knoxflow=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'})
                if path == '/api/dashboard' and method == 'GET':
                    result = service.dashboard(uid)
                elif path == '/api/demo/mail' and method == 'POST':
                    result = service.sample_mail(uid, body)
                elif path == '/api/mail/import' and method == 'POST':
                    result = service.import_mail(uid, body.get('messages'))
                elif path == '/api/profile' and method == 'PATCH':
                    result = service.skills(uid, body)
                elif path == '/api/policy/tick' and method == 'POST':
                    result = service.tick(uid)
                elif path == '/api/resolutions/export' and method == 'GET':
                    return self.send(200, service.export(uid, query.get('month', [''])[0]), 'text/csv; charset=utf-8',
                                     {'Content-Disposition': 'attachment; filename="knoxflow-work-log.csv"'})
                elif len(parts) >= 3 and parts[:2] == ['api', 'tasks']:
                    tid = parts[2]
                    if len(parts) == 3 and method == 'PATCH':
                        result = service.patch_task(uid, tid, body)
                    elif len(parts) == 4 and parts[3] == 'source' and method == 'GET':
                        result = service.source(uid, tid)
                    elif len(parts) == 4 and parts[3] == 'drafts' and method == 'POST':
                        result = service.draft(uid, tid)
                    elif len(parts) == 4 and parts[3] == 'complete' and method == 'POST':
                        result = service.complete(uid, tid, body)
                    elif len(parts) == 4 and parts[3] == 'transfer' and method == 'POST':
                        result = service.transfer(uid, tid, body)
                    elif len(parts) == 4 and parts[3] == 'close' and method == 'POST':
                        result = service.close(uid, tid, body)
                    elif len(parts) == 4 and parts[3] == 'handover' and method == 'POST':
                        result = service.propose(uid, tid, body)
                    else:
                        raise Problem(404, 'Route not found')
                elif len(parts) == 4 and parts[:2] == ['api', 'handovers'] and parts[3] == 'approve' and method == 'POST':
                    result = service.approve(uid, parts[2])
                elif len(parts) == 4 and parts[:2] == ['api', 'handovers'] and parts[3] == 'reject' and method == 'POST':
                    result = service.reject(uid, parts[2])
                elif len(parts) == 4 and parts[:2] == ['api', 'nudges'] and parts[3] == 'ack' and method == 'POST':
                    result = service.acknowledge(uid, parts[2])
                else:
                    raise Problem(404, 'Route not found')
                return self.send(200, result)
            except Problem as error:
                self.send(error.status, dict(error=error.message))
            except (BrokenPipeError, ConnectionResetError):
                pass
            except TimeoutError:
                self.close_connection = True
            except sqlite3.Error:
                self.send(503, dict(error='Local storage is busy. Please retry.'))
            except Exception:
                self.send(500, dict(error='Unexpected server error. No mail content was logged.'))

        do_GET = dispatch
        do_POST = dispatch
        do_PATCH = dispatch

    return Handler


def main():
    parser = argparse.ArgumentParser(description='KnoxFlow local pilot demo')
    parser.add_argument('--port', type=int, default=8000)
    parser.add_argument('--db', default=str(ROOT / 'data' / 'knoxflow.sqlite3'))
    parser.add_argument('--disable-demo-login', action='store_true', help='Deny all demo login/import routes; SSO is not implemented')
    args = parser.parse_args()
    Path(args.db).parent.mkdir(parents=True, exist_ok=True)
    service = Service(args.db)
    service.seed()
    service.seed_logs()
    service.seed_scenarios()
    service.seed_reference_profile()
    service.seed_more_balancing()
    service.seed_compact_demo()
    server = ThreadingHTTPServer(('127.0.0.1', args.port), make_handler(service, allow_demo_login=not args.disable_demo_login))
    print(f'KnoxFlow AI demo: http://127.0.0.1:{args.port}', flush=True)
    print('Synthetic mail only. Ctrl+C to stop.', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
