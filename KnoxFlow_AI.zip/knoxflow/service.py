"""KnoxFlow demo domain service. Rules produce suggestions; there is no LLM or mail send tool."""
import csv
import hashlib
import io
import json
import re
from datetime import datetime, timezone, timedelta
from pathlib import Path
from store import Store

UTC = timezone.utc
SKILLS = {'SAP': ('sap', 'ledger', 'p&l'), 'Reporting': ('report', 'p&l'),
          'Access': ('access', 'permission', 'login'), 'Integration': ('api', 'integration', 'sync')}
PRIORITIES = ('P1', 'P2', 'P3', 'P4')


class Problem(Exception):
    def __init__(self, status, message):
        self.status, self.message = status, message
        super().__init__(message)


def stamp(value=None):
    return (value or datetime.now(UTC)).isoformat()


def date(value):
    try:
        result = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if result.tzinfo is None:
            raise ValueError()
        return result.astimezone(UTC)
    except (ValueError, TypeError, AttributeError):
        raise Problem(400, 'An ISO-8601 timestamp with timezone is required')


def key(*parts):
    return hashlib.sha256(json.dumps(parts).encode()).hexdigest()[:24]


def text(value, field, limit=2000):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise Problem(400, f'{field} must contain 1–{limit} characters')
    return value.strip()


class Service:
    def __init__(self, path, config=None, clock=None):
        self.store = Store(path)
        self.config = config or json.loads(Path(__file__).with_name('config.json').read_text())
        self.clock = clock or (lambda: datetime.now(UTC))

    def now(self):
        return stamp(self.clock())

    def user(self, db, uid):
        if not isinstance(uid, str) or not uid or len(uid) > 80:
            raise Problem(400, 'Invalid user identifier')
        result = self.store.get(db, 'users', uid)
        if not result:
            raise Problem(401, 'Sign in to continue')
        return result

    def users(self):
        with self.store.connect() as db:
            return [{k: u[k] for k in ('id', 'name', 'role', 'team')} for u in self.store.all(db, 'users')]

    def task(self, db, user, task_id, write=False):
        task = self.store.get(db, 'tasks', task_id)
        if not task or task['team'] != user['team']:
            raise Problem(404, 'Task not found')
        if task['owner'] != user['id'] and (write or user['role'] != 'manager'):
            raise Problem(403, 'Task access denied')
        if not self.store.get(db, 'threads', task['thread']):
            raise Problem(403, 'Source access has been revoked')
        return task

    def project(self, user, task):
        result = dict(task)
        result['age_hours'] = round(max(0, (self.clock() - date(task['created_at'])).total_seconds() / 3600), 1)
        result['threshold_hours'] = self.config['thresholds_hours'][task['priority']]
        if user['role'] == 'manager':
            # Allowlist: never return source references, extracted action or raw mail.
            allowed = ('id', 'title', 'client', 'category', 'priority', 'status', 'summary', 'owner',
                       'team', 'version', 'confidence', 'created_at', 'updated_at', 'age_hours', 'threshold_hours')
            projection = {k: result[k] for k in allowed}
            if task.get('status_message_edited'):
                projection['summary'] = f"{task['category']} work for {task['client']}; {task['status'].lower()}."
            return projection
        return result

    def visible_resolution(self, db, user, resolution):
        task = self.store.get(db, 'tasks', resolution['task_id'])
        return bool(task and self.store.get(db, 'threads', task['thread']) and
                    (task['owner'] == user['id'] or (user['role'] == 'manager' and task['team'] == user['team'])))

    def dashboard(self, uid):
        with self.store.connect() as db:
            user = self.user(db, uid)
            team = [u for u in self.store.all(db, 'users') if u['team'] == user['team']]
            tasks = [t for t in self.store.all(db, 'tasks') if t['team'] == user['team'] and
                     (user['role'] == 'manager' or t['owner'] == uid)]
            resolutions = [r for r in self.store.all(db, 'resolutions') if self.visible_resolution(db, user, r)]
            if user['role'] == 'manager':
                resolutions = [{k: r[k] for k in ('id', 'task_id', 'client', 'category', 'owner', 'closed_at', 'priority')} for r in resolutions]
            handovers = [h for h in self.store.all(db, 'handovers') if h['team'] == user['team'] and
                         (user['role'] == 'manager' or uid in (h['from'], h['to']))]
            # Handover summaries must obey the same projection as task cards.
            for handover in handovers:
                source_task = self.store.get(db, 'tasks', handover['task_id'])
                if source_task:
                    projection_user = dict(user, role='manager')
                    handover['summary'] = self.project(projection_user, source_task)['summary']
            nudges = [n for n in self.store.all(db, 'nudges') if n['recipient'] == uid]
            team_tasks = [t for t in self.store.all(db, 'tasks') if t['team'] == user['team']]
            topics = {
                'AI Innovation projects': ('ai innovation', 'ai automation'),
                'SAP BI Report configurations': ('sap bi', 'report configuration', 'p&l'),
                'SAP Authorization': ('authorization', 'sap access'),
                'SAP Asset Management': ('asset management', 'asset register'),
                'SAP Workflow': ('workflow', 'approval path'),
                'SAP Employee Master': ('employee master', 'dept transfer')
            }
            def matches(task, skill):
                if skill not in topics:
                    return task['category'] == skill
                content = (task['title'] + ' ' + task.get('action', '')).lower()
                return any(word in content for word in topics[skill])
            shares = {skill: round(100 * sum(t['owner'] == uid and matches(t, skill) for t in team_tasks) / max(1, sum(matches(t, skill) for t in team_tasks))) for skill in user['skills']}
            return dict(capacity_limit=self.config["capacity_limit"], skill_shares=shares, user=user, team=team, tasks=[self.project(user, t) for t in tasks],
                        resolutions=resolutions, handovers=handovers, nudges=nudges,
                        mode='Local demo · rule-based suggestions', now=self.now(),
                        audit=[a for a in self.store.all(db, 'audit') if a['actor'] in {u['id'] for u in team}][-30:] if user['role'] == 'manager' else [])

    def revoke(self, db, thread_id):
        thread = self.store.get(db, 'threads', thread_id)
        tids = {t['id'] for t in self.store.all(db, 'tasks') if t['thread'] == thread_id}
        for table in ('drafts', 'resolutions', 'handovers', 'nudges'):
            for row in self.store.all(db, table):
                if row.get('task_id') in tids:
                    self.store.delete(db, table, row['id'])
        for tid in tids:
            self.store.delete(db, 'tasks', tid)
        for msg in self.store.all(db, 'messages'):
            if msg['thread'] == thread_id:
                self.store.delete(db, 'messages', msg['id'])
        self.store.delete(db, 'threads', thread_id)
        if thread:
            owner = self.store.get(db, 'users', thread['mailbox'])
            permitted = {t['id'] for t in self.store.all(db, 'threads') if t['mailbox'] == owner['id']}
            body = ' '.join(m['body'] for m in self.store.all(db, 'messages') if m['thread'] in permitted).lower()
            owner['inferred_skills'] = sorted(s for s, words in SKILLS.items() if any(w in body for w in words))
            self.store.put(db, 'users', owner)

    def ingest(self, db, message):
        """Transactional dedup and sample grammar extraction; never execute message instructions."""
        if not isinstance(message, dict):
            raise Problem(400, 'Each message must be an object')
        owner = self.user(db, text(message.get('mailbox'), 'mailbox', 80))
        mid = text(message.get('message_id'), 'message_id', 200)
        thread = key(owner['id'], text(message.get('thread_id'), 'thread_id', 200))
        cat = message.get('classification')
        # Unknown or missing classification fails closed in this demo.
        if cat != 'work' or message.get('private') is not False:
            self.revoke(db, thread)
            self.store.audit(db, owner['id'], 'source_excluded', thread, self.now())
            return 'excluded'
        sent = date(message.get('sent_at'))
        if sent < self.clock() - timedelta(days=60) or sent > self.clock():
            raise Problem(400, 'Message must fall in the authorized last 60 days')
        body = text(message.get('body'), 'body', 20000)
        client = message.get('client')
        if not isinstance(client, str) or client not in self.config['clients']:
            raise Problem(400, 'Client is not configured')
        direction = message.get('direction', 'received')
        if direction not in ('sent', 'received'):
            raise Problem(400, 'direction must be sent or received')
        sender = text(message.get('sender'), 'sender', 200)
        msg_id = key(owner['id'], mid)
        if self.store.get(db, 'messages', msg_id):
            return 'duplicate'
        self.store.put(db, 'threads', dict(id=thread, mailbox=owner['id'], team=owner['team']))
        self.store.put(db, 'messages', dict(id=msg_id, thread=thread, body=body, sender=sender,
                                           sent_at=stamp(sent), client=client, direction=message.get('direction', 'received')))
        # Explicit sample contract: ACTION[stable-key]: action text. No arbitrary model calls.
        actions = re.findall(r'^ACTION\[([a-zA-Z0-9_-]{1,80})\]:\s*(.{1,500})$', body, re.M)
        for action_id, action in actions:
            tid = key(thread, action_id)
            old = self.store.get(db, 'tasks', tid)
            evidence = (action + ' ' + body).lower()
            skill = next((s for s, words in SKILLS.items() if any(w in action.lower() for w in words)), 'General')
            status = 'Awaiting client' if 'awaiting client' in evidence else 'In progress'
            score = (4 if any(w in evidence for w in ('urgent', 'outage', 'critical')) else 0)
            score += self.config['clients'][client]['tier'] + self.config['sender_weights'].get(sender, 0)
            score += min(3, int((self.clock() - sent).total_seconds() / 86400))
            priority = 'P1' if score >= 8 else 'P2' if score >= 5 else 'P3' if score >= 3 else 'P4'
            summary = f'{skill} work for {client}; ' + ('awaiting client confirmation.' if status == 'Awaiting client' else 'consultant action pending.')
            sources = list(dict.fromkeys((old or {}).get('sources', []) + [msg_id]))
            record = dict(id=tid, title=f'{skill} request · {client}', category=skill, client=client,
                          action=action, requestor=sender, owner=owner['id'], team=owner['team'], thread=thread,
                          priority=priority, status=status, summary=summary, confidence=0.72,
                          confidence_basis='Demo rules: explicit ACTION marker and keyword matches',
                          created_at=stamp(sent), updated_at=self.now(), version=1, sources=sources,
                          corrected=False, closure_suggested='resolved' in evidence)
            if old:
                record['created_at'] = min(old['created_at'], stamp(sent))
                record['owner'] = old['owner']
                record['version'] = old['version'] + 1
                if old['corrected'] or old['status'] == 'Closed' or stamp(sent) < old.get('last_message_at', old['created_at']):
                    for field in ('priority', 'status', 'summary', 'confidence', 'action', 'closure_suggested'):
                        record[field] = old[field]
                record['corrected'] = old['corrected']
                record['status_message_edited'] = old.get('status_message_edited', False)
            record['last_message_at'] = max(stamp(sent), (old or {}).get('last_message_at', stamp(sent)))
            self.store.put(db, 'tasks', record)
            pending = self.store.get(db, 'resolutions', tid)
            parsed = self.parse_resolution(db, record)
            if pending and pending.get('evidence_status') == 'Awaiting sent mail' and parsed:
                pending.update(fix=parsed, evidence_status='Parsed from sent mail')
                self.store.put(db, 'resolutions', pending)
        inferred = set(owner.get('inferred_skills', []))
        for skill, words in SKILLS.items():
            if any(w in body.lower() for w in words):
                inferred.add(skill)
        owner['inferred_skills'] = sorted(inferred)
        self.store.put(db, 'users', owner)
        self.store.audit(db, owner['id'], 'message_imported', msg_id, self.now())
        return 'imported'

    def import_mail(self, uid, messages):
        if not isinstance(messages, list) or len(messages) > 200:
            raise Problem(400, 'Provide at most 200 messages')
        result = dict(imported=0, excluded=0, duplicate=0, quarantined=0)
        with self.store.connect() as db:
            user = self.user(db, uid)
            if user['role'] != 'consultant':
                raise Problem(403, 'Only consultants can import their own mail')
            for message in messages:
                if isinstance(message, dict) and message.get('mailbox') != uid:
                    raise Problem(403, 'Cannot import another mailbox')
                db.execute('SAVEPOINT message')
                try:
                    result[self.ingest(db, message)] += 1
                    db.execute('RELEASE message')
                except Problem as error:
                    db.execute('ROLLBACK TO message')
                    db.execute('RELEASE message')
                    qid = key(self.now(), result['quarantined'], uid)
                    self.store.put(db, 'quarantine', dict(id=qid, reason=error.message, at=self.now()))
                    result['quarantined'] += 1
        return result

    def check_version(self, task, version):
        if type(version) is not int or version != task['version']:
            raise Problem(409, 'This task changed. Refresh before trying again.')

    def patch_task(self, uid, tid, data):
        if not isinstance(data, dict) or set(data) - {'version', 'summary', 'priority', 'status'}:
            raise Problem(400, 'Unsupported task update fields')
        with self.store.connect() as db:
            user = self.user(db, uid)
            task = self.task(db, user, tid, write=True)
            self.check_version(task, data.get('version'))
            if task['status'] == 'Closed':
                raise Problem(409, 'Closed tasks cannot be edited')
            if data.get('priority', task['priority']) not in PRIORITIES:
                raise Problem(400, 'Invalid priority')
            # Manager projection is generated from enums, never user-supplied free text.
            if data.get('status', task['status']) not in ('In progress', 'Awaiting client', 'Needs attention'):
                raise Problem(400, 'Invalid status')
            for field in ('priority', 'status'):
                if field in data:
                    task[field] = data[field]
            if 'summary' in data:
                task['summary'] = text(data['summary'], 'Status message', 1000)
                task['status_message_edited'] = True
            elif 'status' in data:
                task['summary'] = f"{task['category']} work for {task['client']}; {task['status'].lower()}."
            task.update(corrected=True, version=task['version'] + 1, updated_at=self.now())
            self.store.put(db, 'tasks', task)
            self.store.audit(db, uid, 'task_corrected', tid, self.now())
            return self.project(user, task)

    def source(self, uid, tid):
        with self.store.connect() as db:
            user = self.user(db, uid)
            task = self.task(db, user, tid)
            if user['role'] == 'manager':
                raise Problem(403, 'Managers cannot read mail')
            thread = self.store.get(db, 'threads', task['thread'])
            if thread['mailbox'] != uid:
                return dict(messages=[], summary=task['summary'], notice='Approved handover context only; original mailbox is not shared.')
            return dict(messages=[self.store.get(db, 'messages', s) for s in task['sources']], summary=task['summary'])

    def parse_resolution(self, db, task):
        messages = [self.store.get(db, 'messages', mid) for mid in task['sources']]
        for message in sorted((m for m in messages if m and m.get('direction') == 'sent'), key=lambda m: m['sent_at'], reverse=True):
            matches = re.finditer(r'^RESOLUTION(?:\[([a-zA-Z0-9_-]+)\])?:\s*(.{1,2000})$', message['body'], re.M)
            for match in matches:
                if match.group(1) and key(task['thread'], match.group(1)) != task['id']:
                    continue
                if not match.group(1) and len(re.findall(r'^ACTION\[', message['body'], re.M)) > 1:
                    continue
                return match.group(2).strip()
        return ''

    def complete(self, uid, tid, data):
        with self.store.connect() as db:
            user = self.user(db, uid)
            task = self.task(db, user, tid, write=True)
            existing = self.store.get(db, 'resolutions', tid)
            if existing:
                return existing
            self.check_version(task, data.get('version'))
            fix = self.parse_resolution(db, task)
            resolution = dict(id=tid, task_id=tid, owner=uid, team=task['team'], client=task['client'],
                              issue=task['action'], category=task['category'], priority=task['priority'],
                              fix=fix, evidence_status='Parsed from sent mail' if fix else 'Awaiting sent mail', closed_at=self.now())
            task.update(status='Closed', summary=f"{task['category']} request completed.", closure_suggested=False,
                        updated_at=self.now(), version=task['version'] + 1)
            self.store.put(db, 'tasks', task)
            self.store.put(db, 'resolutions', resolution)
            self.store.audit(db, uid, 'task_completed', tid, self.now())
            return resolution

    def transfer(self, uid, tid, data):
        with self.store.connect() as db:
            manager = self.user(db, uid)
            task = self.task(db, manager, tid)
            target = self.user(db, data.get('to'))
            if manager['role'] != 'manager' or target['role'] != 'consultant' or target['team'] != manager['team']:
                raise Problem(403, 'Same-team manager reassignment required')
            self.check_version(task, data.get('version'))
            if task['status'] == 'Closed' or target['id'] == task['owner']:
                raise Problem(409, 'Select an active task and a different teammate')
            task.update(owner=target['id'], updated_at=self.now(), version=task['version'] + 1)
            self.store.put(db, 'tasks', task)
            self.store.audit(db, uid, 'manual_reassignment_approved', tid, self.now())
            return self.project(manager, task)

    def close(self, uid, tid, data):
        with self.store.connect() as db:
            user = self.user(db, uid)
            task = self.task(db, user, tid, write=True)
            existing = self.store.get(db, 'resolutions', tid)
            if existing:
                return existing
            self.check_version(task, data.get('version'))
            fix = text(data.get('fix'), 'Confirmed resolution', 2000)
            resolution = dict(id=tid, task_id=tid, owner=uid, team=task['team'], client=task['client'],
                              issue=task['action'], category=task['category'], priority=task['priority'],
                              fix=fix, closed_at=self.now())
            task.update(status='Closed', summary=f"{task['category']} request resolved; consultant confirmed closure.",
                        version=task['version'] + 1, updated_at=self.now(), closure_suggested=False)
            self.store.put(db, 'tasks', task)
            self.store.put(db, 'resolutions', resolution)
            self.store.audit(db, uid, 'resolution_confirmed', tid, self.now())
            return resolution

    def draft(self, uid, tid):
        with self.store.connect() as db:
            user = self.user(db, uid)
            task = self.task(db, user, tid, write=True)
            if task['status'] == 'Closed':
                raise Problem(409, 'Task is closed')
            # Conservative exact client/category match, authorized sources only.
            matches = [r for r in self.store.all(db, 'resolutions') if r['client'] == task['client'] and
                       r['category'] == task['category'] and r.get('fix') and self.visible_resolution(db, user, r)]
            if not matches:
                return dict(match=False, message='No match', sources=[])
            chosen = sorted(matches, key=lambda r: r['closed_at'])[-1]
            body = f"Hello,\n\nA previous resolution for this category was:\n{chosen['fix']}\n\nI will verify whether these steps apply to this request.\n\nRegards,\n{user['name']}"
            record = dict(id=key(tid, chosen['id'], task['version']), task_id=tid, owner=uid,
                          body=body, source=chosen['id'], created_at=self.now())
            self.store.put(db, 'drafts', record)
            self.store.audit(db, uid, 'draft_suggested', tid, self.now())
            return dict(match=True, body=body, sources=[chosen['id']], notice='Rule-based retrieval. Review applicability before sending in Knox.')

    def skills(self, uid, data):
        with self.store.connect() as db:
            user = self.user(db, uid)
            if user['role'] != 'consultant':
                raise Problem(403, 'Only consultants maintain a skills profile')
            skills = data.get('skills')
            if not isinstance(skills, list) or len(skills) > 20:
                raise Problem(400, 'Provide at most 20 skills')
            user['skills'] = sorted(set(text(s, 'skill', 60) for s in skills))
            user['skills_reviewed'] = True
            if 'on_leave' in data:
                if type(data['on_leave']) is not bool:
                    raise Problem(400, 'on_leave must be true or false')
                user['on_leave'] = data['on_leave']
            self.store.put(db, 'users', user)
            self.store.audit(db, uid, 'skills_updated', uid, self.now())
            return user

    def candidates(self, db, task):
        tasks = self.store.all(db, 'tasks')
        result = []
        for user in self.store.all(db, 'users'):
            if user['team'] != task['team'] or user['role'] != 'consultant' or user['on_leave'] or user['id'] == task['owner']:
                continue
            effective = user['skills'] if user.get('skills_reviewed') else user.get('inferred_skills', [])
            if task['category'] not in effective:
                continue
            active = sum(t['owner'] == user['id'] and t['status'] != 'Closed' for t in tasks)
            if active < self.config['capacity_limit']:
                result.append(dict(id=user['id'], name=user['name'], active=active, skills=effective))
        return sorted(result, key=lambda u: (u['active'], u['name']))

    def propose(self, uid, tid, data):
        with self.store.connect() as db:
            user = self.user(db, uid)
            task = self.task(db, user, tid)
            if task['status'] == 'Closed':
                raise Problem(409, 'Task is closed')
            self.check_version(task, data.get('version'))
            candidates = self.candidates(db, task)
            if not candidates:
                self.store.audit(db, uid, 'no_backup_manager_attention', tid, self.now())
                return dict(match=False, message='No suitable backup. Owner unchanged; flagged in manager audit.')
            selected = next((c for c in candidates if c['id'] == data.get('to')), candidates[0] if not data.get('to') else None)
            if not selected:
                raise Problem(400, 'Selected backup is unavailable or lacks the required skill')
            record = dict(id=key(tid, task['version'], selected['id']), task_id=tid, team=task['team'],
                          title=task['title'], summary=task['summary'], **{'from': task['owner'], 'to': selected['id']},
                          task_version=task['version'], status='Pending', created_at=self.now())
            old = self.store.get(db, 'handovers', record['id'])
            if not old:
                self.store.put(db, 'handovers', record)
                self.store.audit(db, uid, 'handover_proposed', tid, self.now())
            return dict(match=True, handover=old or record, candidates=candidates)

    def approve(self, uid, hid):
        with self.store.connect() as db:
            user = self.user(db, uid)
            handover = self.store.get(db, 'handovers', hid)
            if user['role'] != 'manager' or not handover or handover['team'] != user['team']:
                raise Problem(403, 'Manager approval required')
            if handover['status'] != 'Pending':
                raise Problem(409, 'Handover already reviewed')
            task = self.task(db, user, handover['task_id'])
            self.check_version(task, handover['task_version'])
            if task['status'] == 'Closed' or handover['to'] not in [u['id'] for u in self.candidates(db, task)]:
                raise Problem(409, 'Backup eligibility changed. Propose again.')
            task.update(owner=handover['to'], version=task['version'] + 1, updated_at=self.now())
            # Old owner loses task access; no full mailbox access is granted to backup.
            self.store.put(db, 'tasks', task)
            handover.update(status='Approved', approved_at=self.now(), approved_by=uid)
            self.store.put(db, 'handovers', handover)
            self.store.audit(db, uid, 'handover_approved', task['id'], self.now())
            return handover

    def reject(self, uid, hid):
        with self.store.connect() as db:
            user = self.user(db, uid)
            handover = self.store.get(db, 'handovers', hid)
            if user['role'] != 'manager' or not handover or handover['team'] != user['team']:
                raise Problem(403, 'Manager approval required')
            if handover['status'] != 'Pending':
                raise Problem(409, 'Handover already reviewed')
            handover.update(status='Rejected', reviewed_at=self.now(), reviewed_by=uid)
            self.store.put(db, 'handovers', handover)
            self.store.audit(db, uid, 'handover_rejected', handover['task_id'], self.now())
            return handover

    def tick(self, uid):
        with self.store.connect() as db:
            user = self.user(db, uid)
            if user['role'] != 'manager':
                raise Problem(403, 'Manager role required')
            created = 0
            for task in self.store.all(db, 'tasks'):
                if task['team'] != user['team'] or task['status'] == 'Closed':
                    continue
                age = (self.clock() - date(task['created_at'])).total_seconds() / 3600
                if age < self.config['thresholds_hours'][task['priority']]:
                    continue
                first_id = key(task['id'], 'consultant', task['owner'])
                first = self.store.get(db, 'nudges', first_id)
                if not first:
                    first = dict(id=first_id, task_id=task['id'], title=task['title'], recipient=task['owner'],
                                 tier='Consultant', created_at=self.now(), acknowledged=False)
                    self.store.put(db, 'nudges', first)
                    created += 1
                elif not first['acknowledged'] and (self.clock() - date(first['created_at'])).total_seconds() / 3600 >= self.config['manager_delay_hours']:
                    nid = key(first_id, 'manager')
                    if not self.store.get(db, 'nudges', nid):
                        self.store.put(db, 'nudges', dict(id=nid, task_id=task['id'], title=task['title'],
                            recipient=uid, tier='Manager', created_at=self.now(), acknowledged=False))
                        created += 1
            self.store.audit(db, uid, 'nudge_policy_evaluated', str(created), self.now())
            return dict(created=created)

    def acknowledge(self, uid, nid):
        with self.store.connect() as db:
            self.user(db, uid)
            nudge = self.store.get(db, 'nudges', nid)
            if not nudge or nudge['recipient'] != uid:
                raise Problem(404, 'Nudge not found')
            nudge.update(acknowledged=True, acknowledged_at=self.now())
            self.store.put(db, 'nudges', nudge)
            self.store.audit(db, uid, 'nudge_acknowledged', nid, self.now())
            return nudge

    def export(self, uid, month):
        if not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])', month or ''):
            raise Problem(400, 'month must be YYYY-MM')
        with self.store.connect() as db:
            user = self.user(db, uid)
            output = io.StringIO(newline='')
            writer = csv.writer(output)
            fields = ['client', 'issue', 'category', 'priority', 'fix', 'owner', 'closed_at']
            if user['role'] == 'manager':
                fields = ['client', 'category', 'priority', 'owner', 'closed_at']
            writer.writerow(fields)
            for row in self.store.all(db, 'resolutions'):
                if row['closed_at'].startswith(month) and self.visible_resolution(db, user, row):
                    # Neutralize spreadsheet formula injection, including prefixed whitespace.
                    values = [str(row.get(f, '')) for f in fields]
                    writer.writerow(["'" + v if v.lstrip().startswith(('=', '+', '-', '@')) or v.startswith(('\t', '\r', '\n')) else v for v in values])
            self.store.audit(db, uid, 'resolution_exported', month, self.now())
            return output.getvalue()

    def seed(self):
        with self.store.connect() as db:
            if self.store.all(db, 'users'):
                return
            users = [dict(id='alex', name='Sidhant Nayak', role='consultant', team='Client Operations', skills=['SAP', 'Reporting'], on_leave=False),
                     dict(id='priya', name='John Doe', role='consultant', team='Client Operations', skills=['SAP', 'Access', 'Reporting'], on_leave=False),
                     dict(id='daniel', name='Matthew Lee', role='consultant', team='Client Operations', skills=['Integration', 'Access'], on_leave=True),
                     dict(id='sarita', name='Sarita Shukla', role='consultant', team='Client Operations', skills=['Reporting'], on_leave=False),
                     dict(id='pushpak', name='Pushpak Kumar', role='consultant', team='Client Operations', skills=['Integration', 'Access'], on_leave=False),
                     dict(id='morgan', name='Alakh Singh', role='manager', team='Client Operations', skills=[], on_leave=False)]
            for user in users:
                user.update(inferred_skills=[], skills_reviewed=True)
                self.store.put(db, 'users', user)
            examples = [('alex','Han River','SAP ledger reconciliation','urgent outage in ledger; review requested',30),
                        ('alex','Han River','P&L report validation','awaiting client confirmation',9),
                        ('alex','Orion','SAP ledger close','resolved after authorized reconciliation',48),
                        ('alex','Maple','Reporting monthly report','prepare monthly report',5),
                        ('priya','Han River','Access login reset','urgent access request',3),
                        ('priya','Orion','SAP ledger review','awaiting client approval',16),
                        ('daniel','Maple','Integration API sync failure','urgent API sync outage',12),
                        ('alex','Orion','SAP ledger variance','review against previous reconciliation fix',2),
                        ('sarita','Maple','Reporting dashboard refresh','awaiting client review',6),
                        ('pushpak','Maple','Integration API review','review requested',4)]
            for i, (owner, client, action, context, hours) in enumerate(examples):
                msg = dict(mailbox=owner, message_id=f'demo-{i}', thread_id=f'thread-{i}', classification='work', private=False,
                           client=client, sender='operations@hanriver.example' if client == 'Han River' else 'support@client.example',
                           sent_at=stamp(self.clock() - timedelta(hours=hours)), body=f'ACTION[request]: {action}\n{context}')
                self.ingest(db, msg)
        # A confirmed past resolution demonstrates authorized retrieval.
        resolved = next(t for t in self.dashboard('alex')['tasks'] if t['client'] == 'Orion' and t['closure_suggested'])
        self.close('alex', resolved['id'], dict(version=resolved['version'], fix='Verified the ledger mapping against the approved configuration and reran reconciliation. Confirmed totals with the client.'))

    def seed_logs(self):
        """Idempotent synthetic sent-mail history for immediately useful CSV exports."""
        for uid, client, category, issue, fix in [
            ('alex', 'Han River', 'SAP', 'SAP authorization recovery', 'Validated authorization mapping and restored approved access.'),
            ('alex', 'Maple', 'Reporting', 'Monthly report correction', 'Corrected the report filters and sent verified totals.'),
            ('priya', 'Han River', 'Access', 'Client login reset', 'Reset the authorized login and verified client access.'),
            ('daniel', 'Maple', 'Integration', 'API sync repair', 'Reprocessed the failed batch after validating the API configuration.'),
            ('sarita', 'Maple', 'Reporting', 'Dashboard report verification', 'Validated report output and received client confirmation.'),
            ('pushpak', 'Orion', 'Integration', 'Interface monitoring fix', 'Restored the scheduled interface and confirmed successful delivery.')]:
            marker = 'log-' + uid + '-' + category
            self.import_mail(uid, [dict(mailbox=uid, message_id=marker, thread_id=marker,
                classification='work', private=False, client=client, sender=uid+'@sdsi.example',
                direction='sent', sent_at=stamp(self.clock() - timedelta(hours=6)),
                body=f'ACTION[resolved]: {issue}\nRESOLUTION: {fix}\nresolved')])
            with self.store.connect() as db:
                task = self.store.get(db, 'tasks', key(key(uid, marker), 'resolved'))
            if task and task['status'] != 'Closed':
                self.complete(uid, task['id'], dict(version=task['version']))

    def seed_scenarios(self):
        """Seed a rich, repeatable demo once; never recreate approved suggestions."""
        with self.store.connect() as db:
            if any(a['action'] == 'expanded_scenarios_initialized' for a in self.store.all(db, 'audit')):
                return
        examples = {
            'alex': [('SAP BI P&L report validation', 'Han River'), ('Dept transfer SAP access review', 'Orion'), ('Treasury SAP approval path change', 'Han River'), ('FICO SAP T-code requirement', 'Maple')],
            'priya': [('SLA report for client operations', 'Orion'), ('License access renewal tracking', 'Maple'), ('Vendor SAP invoice reconciliation', 'Han River'), ('Monthly report template update', 'Orion')],
            'daniel': [('Sales Portal access fix', 'Han River'), ('Quarterly compliance report API feed', 'Maple'), ('Client login authorization review', 'Orion'), ('Integration sync alert follow-up', 'Han River')],
            'sarita': [('Vendor report reconciliation', 'Orion'), ('Dashboard report refresh', 'Maple'), ('Client reporting training update', 'Han River'), ('Monthly report discrepancy check', 'Orion')],
            'pushpak': [('Incident API post-mortem follow-up', 'Han River'), ('Capacity planning integration inputs', 'Maple'), ('Security access patch confirmation', 'Orion'), ('Backup integration schedule change', 'Maple')]
        }
        for uid, entries in examples.items():
            for i, (issue, client) in enumerate(entries):
                marker = f'scenario-{uid}-{i}'
                message = dict(mailbox=uid, message_id=marker, thread_id=marker, classification='work', private=False,
                               client=client, sender=f'client.{i+1}@operations.example', sent_at=stamp(self.clock()-timedelta(hours=3+i*7)),
                               body=f'ACTION[request]: {issue}\n'+('Urgent client follow-up required.' if i==0 else 'Awaiting client confirmation.' if i==1 else 'Please review the request.'))
                self.import_mail(uid, [message])
                with self.store.connect() as db:
                    task = self.store.get(db, 'tasks', key(key(uid, marker), 'request'))
                    if task and not task['corrected']:
                        task['title'] = issue
                        self.store.put(db, 'tasks', task)
        tid = key(key('daniel', 'scenario-daniel-0'), 'request')
        with self.store.connect() as db:
            task = self.store.get(db, 'tasks', tid)
        result = self.propose('morgan', tid, dict(version=task['version'], to='pushpak'))
        if result.get('match'):
            with self.store.connect() as db:
                h = result['handover']
                h['reason'] = 'Matthew Lee is on leave. Pushpak Kumar has Access skills and available capacity. Approve to move this urgent client task immediately.'
                self.store.put(db, 'handovers', h)
        with self.store.connect() as db:
            self.store.audit(db, 'morgan', 'expanded_scenarios_initialized', 'v5', self.now())

    def sample_mail(self, uid, data):
        """Demo-only synthetic mail generator; no mailbox provider or send operation."""
        with self.store.connect() as db:
            user = self.user(db, uid)
            mailbox = data.get('mailbox', uid) if user['role'] == 'manager' else uid
            target = self.user(db, mailbox)
            if target['role'] != 'consultant' or target['team'] != user['team']:
                raise Problem(403, 'Select a consultant within your team')
        subject = text(data.get('subject'), 'Subject', 200)
        body = text(data.get('body'), 'Mail text', 4000)
        if re.search(r'^ACTION\[', subject + '\n' + body, re.M):
            raise Problem(400, 'Use plain text in the sample form')
        request_id = data.get('request_id')
        if request_id is not None:
            request_id = text(request_id, 'request_id', 100)
        marker = 'popup-' + key(uid, request_id) if request_id else 'popup-' + key(self.now(), uid, subject)
        message = dict(mailbox=mailbox, message_id=marker, thread_id=marker, classification='work', private=False,
                       client=data.get('client'), sender=text(data.get('sender'), 'Sender', 200),
                       sent_at=self.now(), body=f'ACTION[request]: {subject}\n{body}')
        result = self.import_mail(mailbox, [message])
        return dict(result=result, mailbox=mailbox)

    def seed_reference_profile(self):
        """Add consultant-reference skills once; preserve subsequent employee edits."""
        reference = ['AI Innovation projects', 'SAP BI Report configurations', 'SAP Authorization',
                     'SAP Asset Management', 'SAP Workflow', 'SAP Employee Master']
        with self.store.connect() as db:
            if any(a['action'] == 'reference_skills_initialized' for a in self.store.all(db, 'audit')):
                return
            user = self.user(db, 'alex')
            user['skills'] = list(dict.fromkeys(user['skills'] + reference))
            self.store.put(db, 'users', user)
        examples = [('AI innovation automation pilot', 'Maple'), ('SAP BI report configuration validation', 'Han River'),
                    ('SAP authorization review', 'Orion'), ('SAP asset management register update', 'Han River'),
                    ('SAP workflow approval routing', 'Orion'), ('SAP employee master data correction', 'Maple')]
        for i, (issue, client) in enumerate(examples):
            marker = f'reference-skill-{i}'
            self.import_mail('alex', [dict(mailbox='alex', message_id=marker, thread_id=marker,
                classification='work', private=False, client=client, sender='client.reference@example.test',
                sent_at=stamp(self.clock()-timedelta(hours=6+i*11)),
                body=f'ACTION[request]: {issue}\nAwaiting client confirmation.')])
        with self.store.connect() as db:
            self.store.audit(db, 'alex', 'reference_skills_initialized', 'v6', self.now())

    def seed_more_balancing(self):
        """Create supporting sample tasks and three extra proposals once, atomically."""
        examples = [
            ('daniel', 'priya', 'Han River', 'Client portal login access recovery'),
            ('daniel', 'priya', 'Orion', 'Treasury user access provisioning'),
            ('daniel', 'priya', 'Maple', 'Procurement login permission review'),
            ('daniel', 'priya', 'Han River', 'Finance application access restoration'),
            ('daniel', 'priya', 'Orion', 'Vendor portal access approval'),
            ('daniel', 'priya', 'Maple', 'Client workspace login permission fix'),
            ('daniel', 'pushpak', 'Han River', 'Sales API integration retry recovery'),
            ('daniel', 'pushpak', 'Orion', 'Payroll interface API sync check'),
            ('daniel', 'pushpak', 'Maple', 'Warehouse integration batch restart'),
            ('daniel', 'pushpak', 'Han River', 'Client API response mapping correction'),
            ('daniel', 'pushpak', 'Orion', 'Inventory integration sync reconciliation'),
            ('daniel', 'pushpak', 'Maple', 'Invoice API delivery verification'),
            ('alex', 'sarita', 'Han River', 'Monthly reporting variance validation'),
            ('alex', 'sarita', 'Orion', 'Compliance report formatting review'),
            ('alex', 'sarita', 'Maple', 'Client report scheduling correction'),
            ('alex', 'sarita', 'Han River', 'Revenue report reconciliation follow-up'),
            ('alex', 'sarita', 'Orion', 'Quarterly report export verification'),
            ('alex', 'sarita', 'Maple', 'Operational dashboard report refresh')
        ]
        with self.store.connect() as db:
            if any(a['action'] == 'balancing_examples_v9_initialized' for a in self.store.all(db, 'audit')):
                return
            for i, (owner, target, client, title) in enumerate(examples):
                marker = f'balancing-v9-{i+1:02d}'
                # All content here is authored synthetic demo data, never real mail.
                self.ingest(db, dict(mailbox=owner, message_id=marker, thread_id=marker,
                    classification='work', private=False, client=client,
                    sender=f'operations.{i+1}@client.example',
                    sent_at=stamp(self.clock()-timedelta(hours=4+i*3)),
                    body=f'ACTION[request]: {title}\nUrgent client follow-up required.'))
                task = self.store.get(db, 'tasks', key(key(owner, marker), 'request'))
                task['title'] = title
                self.store.put(db, 'tasks', task)
                if i not in (0, 6, 12):
                    continue
                if target not in [u['id'] for u in self.candidates(db, task)]:
                    # An existing installation may have employee-edited skills or
                    # leave states; do not silently overwrite those choices.
                    self.store.audit(db, 'morgan', 'sample_backup_unavailable', task['id'], self.now())
                    continue
                source = self.user(db, owner)
                backup = self.user(db, target)
                reason = (f"{source['name']} is on leave." if source['on_leave'] else
                          f"{source['name']} has a concentrated reporting workload.")
                reason += f" {backup['name']} has matching {task['category']} skills and available capacity. Approve to transfer this client request."
                proposal = dict(id=key(task['id'], task['version'], target), task_id=task['id'],
                    team=task['team'], title=title, summary=task['summary'], task_version=task['version'],
                    status='Pending', created_at=self.now(), reason=reason, scenario='expanded-balancing-v9',
                    **{'from':owner,'to':target})
                self.store.put(db, 'handovers', proposal)
                self.store.audit(db, 'morgan', 'handover_proposed', task['id'], self.now())
            self.store.audit(db, 'morgan', 'balancing_examples_v9_initialized', '18 samples', self.now())

    def seed_compact_demo(self):
        """Apply the smaller sample presentation once; preserve employee changes."""
        with self.store.connect() as db:
            if any(a['action'] == 'compact_demo_v10_initialized' for a in self.store.all(db, 'audit')):
                return
            keep = {key(key(owner, f'balancing-v9-{index:02d}'), 'request')
                    for owner, index in [('daniel', 1), ('daniel', 7), ('alex', 13)]}
            for handover in self.store.all(db, 'handovers'):
                if handover.get('scenario') == 'expanded-balancing-v9' and handover['task_id'] not in keep:
                    handover['archived_sample'] = True
                    if handover['status'] == 'Pending':
                        handover['status'] = 'Archived'
                    self.store.put(db, 'handovers', handover)
            # Remove exactly two untouched synthetic requests from each person.
            for owner in ('alex', 'priya', 'daniel', 'sarita', 'pushpak'):
                for index in ((1, 2) if owner == 'alex' else (2, 3)):
                    thread = key(owner, f'scenario-{owner}-{index}')
                    task = self.store.get(db, 'tasks', key(thread, 'request'))
                    if task and task['owner'] == owner and not task['corrected'] and task['status'] != 'Closed':
                        self.revoke(db, thread)
            fico = self.store.get(db, 'tasks', key(key('alex', 'scenario-alex-3'), 'request'))
            if fico and fico['owner'] == 'alex' and not fico['corrected'] and fico['status'] != 'Closed':
                fico.update(title='T-code requirement - FICO', action='T-code requirement - FICO',
                            requestor='ally.lee', summary='Instructions shared with Ms Lee',
                            closure_suggested=True, status='Awaiting client')
                self.store.put(db, 'tasks', fico)
            self.store.audit(db, 'morgan', 'compact_demo_v10_initialized', '4 suggestions; 2 fewer tasks per consultant', self.now())
