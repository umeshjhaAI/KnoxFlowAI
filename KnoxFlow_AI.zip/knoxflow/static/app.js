'use strict';
let state, csrf = '', view = 'Overview', statusFilter = 'Active', search = '', priorityFilter = 'All';
const $ = id => document.getElementById(id);
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const initials = name => name.split(' ').map(x => x[0]).join('').slice(0,2);
const person = id => state.team.find(u => u.id === id)?.name || id;
const isManager = () => state.user.role === 'manager';
const badge = t => `<span class="badge ${esc(t.priority)}">${esc(t.priority)} · ${ {P1:'Critical',P2:'High',P3:'Medium',P4:'Low'}[t.priority]}</span>`;
const time = value => new Date(value).toLocaleString([], {month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'});
let toastTimer;
function toast(message){ $('toast').textContent=message; $('toast').style.display='block'; clearTimeout(toastTimer); toastTimer=setTimeout(()=>$('toast').style.display='none',5500); }
async function api(path, method='GET', data){
  const response = await fetch('/api'+path,{method,headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:data===undefined?undefined:JSON.stringify(data)});
  const result = await response.json();
  if(!response.ok) throw new Error(result.error || 'Request failed');
  return result;
}
async function refresh(){ state=await api('/dashboard'); render(); }
function showModal(html){ $('modal-content').innerHTML=html; if(!$('modal').open)$('modal').showModal(); }
function stat(title,value,note,icon,warning=false){return `<div class="stat"><div class="stat-top">${title}<span class="stat-icon">${icon}</span></div><div class="stat-value">${value}</div><div class="stat-note ${warning?'warn':''}">${note}</div></button>`;}
function active(){return state.tasks.filter(t=>t.status!=='Closed');}
function head(title,sub,button=''){return `<div class="page-head"><div><p class="eyebrow">YOUR OPERATIONS, CONNECTED</p><h1>${title}</h1><p class="subtext">${sub}</p></div>${button}</div>`;}
function empty(message){return `<div class="empty">${message}</div>`;}
function rail(){
  return `<div class="rail"><section class="panel"><div class="panel-head"><h2>Team pulse</h2><span class="tiny">${state.team.filter(u=>u.role==='consultant').length} people</span></div><div class="panel-body">${state.team.filter(u=>u.role==='consultant').map(u=>{
    const count = state.tasks.filter(t=>t.owner===u.id&&t.status!=='Closed').length;
    return `<div class="member"><div class="member-top"><div class="person"><span class="avatar">${initials(u.name)}</span><div><div class="person-name">${esc(u.name)}</div><div class="task-meta">${isManager()?count+' active tasks':'Capacity visible to manager'}</div></div></div>${u.on_leave?'<span class="leave">On leave</span>':''}</div>${isManager()?`<div class="progress"><i style="width:${Math.min(100,count/(state.capacity_limit||8)*100)}%"></i></div>`:''}<div>${u.skills.map(s=>`<span class="skill-tag">${esc(s)}</span>`).join('')}</div></div>`;
  }).join('')}</div></section><div class="insight"><h3>✦ Context that travels with work</h3><p>Skill-matched backups receive a concise task summary after manager approval. Task age and escalation history stay attached.</p><button class="button small soft" data-view="Handovers">Review handovers →</button></div></div>`;
}
function taskRows(tasks){return tasks.map(t=>`<tr class="task-row" data-action="detail" data-id="${t.id}"><td><div class="task-title">${esc(t.title)}</div><div class="task-meta">${esc(t.client)} · ${isManager()?esc(person(t.owner)):esc(t.action)}</div></td><td>${badge(t)}</td><td><span class="status ${t.status==='Closed'?'closed':''}">${esc(t.status)}</span><div class="confidence">${Math.round(t.confidence*100)}% rules confidence</div></td><td><span class="${t.age_hours>t.threshold_hours&&t.status!=='Closed'?'stat-note warn':'muted'}">${t.age_hours}h</span></td><td><button class="button small secondary" data-action="detail" data-id="${t.id}">Open ↗</button></td></tr>`).join('');}
function tasksPanel(){
  let tasks=state.tasks.filter(t=>(statusFilter==='All'||(statusFilter==='Closed'?t.status==='Closed':t.status!=='Closed'))&&(priorityFilter==='All'||t.priority===priorityFilter)&&(t.title+' '+t.client+' '+(t.action||'')).toLowerCase().includes(search.toLowerCase()));
  tasks.sort((a,b)=>a.priority.localeCompare(b.priority)||b.age_hours-a.age_hours);
  return `<section class="panel"><div class="panel-head"><div><h2>${isManager()?'Team workstream':'Your workstream'}</h2><p>Every request, with the context to move it forward.</p></div><span class="tiny">${tasks.length} tasks</span></div><div class="toolbar"><input class="search" id="search" placeholder="Search tasks or clients…" aria-label="Search tasks" value="${esc(search)}"><select id="priority-filter" aria-label="Filter priority">${['All','P1','P2','P3','P4'].map(p=>`<option ${priorityFilter===p?'selected':''}>${p}</option>`).join('')}</select></div><div class="tabs">${['Active','Closed','All'].map(s=>`<button data-filter="${s}" class="${s===statusFilter?'active':''}">${s}<span class="count">${state.tasks.filter(t=>s==='All'||(s==='Closed'?t.status==='Closed':t.status!=='Closed')).length}</span></button>`).join('')}</div>${tasks.length?`<div class="table-wrap"><table><thead><tr><th>Task / client</th><th>Priority</th><th>Contextual status</th><th>Age</th><th></th></tr></thead><tbody>${taskRows(tasks)}</tbody></table></div>`:empty('No tasks match your filters.')}</section>`;
}
function overview(){
  const tasks=active(), critical=tasks.filter(t=>t.priority==='P1').length, waiting=tasks.filter(t=>t.status==='Awaiting client').length;
  return head(isManager()?'A clearer view of your team.':`Good to see you, ${esc(state.user.name.split(' ')[0])}.`,isManager()?'Spot stalled work, balance capacity, and keep client commitments moving.':'Less inbox hunting. More time for the work that matters.',`<button class="button secondary" data-action="refresh">↻ Refresh</button>`)+
    `<div class="stats">${stat('Active work',tasks.length,isManager()?'Across your team':'Assigned to you','▤')}${stat('Needs attention',critical,'Critical priority requests','⚑',critical>0)}${stat('Awaiting client',waiting,'Keep the conversation moving','◷')}${stat('Confirmed resolutions',state.resolutions.length,'Captured in your work log','✓')}</div><div class="grid"><div>${tasksPanel()}</div>${rail()}</div>`;
}
function handovers(){return head('Keep work moving.','Skill-matched suggestions. Manager-approved transitions.')+`<section class="panel"><div class="panel-head"><h2>Handover requests</h2><span class="tiny">Approval required for every reassignment</span></div>${state.handovers.length?state.handovers.map(h=>`<div class="list-item"><div class="list-top"><h3>${esc(h.title)}</h3><span class="badge ${h.status==='Approved'?'closed':'P2'}">${esc(h.status)}</span></div><p>${esc(h.summary)}</p><div class="stack"><span class="muted">${esc(person(h.from))} → ${esc(person(h.to))}</span>${h.status==='Pending'&&isManager()?`<button class="button small" data-action="approve" data-id="${h.id}">Approve handover</button>`:''}</div><div class="task-meta">Proposed ${time(h.created_at)} · Task version ${h.task_version}</div></div>`).join(''):empty('No handovers yet. Open a task and select “Find backup” to propose one.')}</section><div class="code-note">Original mail bodies remain in the source mailbox. Backups receive task context only. An approval is rejected if the task version or backup availability changes.</div>`;}
function nudges(){return head('Follow up before it escalates.','Consultant reminders come first; unacknowledged work is then raised to the manager.',isManager()?'<button class="button" data-action="tick">Run nudge check</button>':'')+`<section class="panel"><div class="panel-head"><h2>Your notifications</h2><span class="tiny">Elapsed UTC hours · Manual demo check</span></div>${state.nudges.length?state.nudges.map(n=>`<div class="list-item"><div class="list-top"><h3>${esc(n.title)}</h3><span class="badge ${n.acknowledged?'closed':'P2'}">${n.acknowledged?'Acknowledged':esc(n.tier)+' reminder'}</span></div><p>Created ${time(n.created_at)}</p>${!n.acknowledged?`<button class="button small secondary" data-action="ack" data-id="${n.id}">Acknowledge</button>`:''}</div>`).join(''):empty('No notifications for this identity. Managers can run a nudge check to evaluate pending tasks.')}</section><div class="code-note">Configured thresholds: P1 2h · P2 8h · P3 24h · P4 72h. Manager alert follows 2h after an unacknowledged consultant reminder. This demo does not send external notifications.</div>`;}
function resolutions(){return head('A record of work, naturally.','Confirmed resolutions become authorized knowledge for future requests.')+`<section class="panel"><div class="panel-head"><h2>Monthly work log</h2><div class="stack"><input type="month" id="export-month" aria-label="Export month" value="${state.now.slice(0,7)}"><button class="button small" data-action="export">↓ Export CSV</button></div></div>${state.resolutions.length?state.resolutions.map(r=>`<div class="list-item"><div class="list-top"><h3>${esc(r.category)} · ${esc(r.client)}</h3><span class="badge closed">Confirmed</span></div>${isManager()?'':`<p>${esc(r.fix||"Awaiting resolution from sent mail")}</p>`}<div class="task-meta">${esc(person(r.owner))} · ${time(r.closed_at)} · ${esc(r.priority)}</div></div>`).join(''):empty('No confirmed resolutions yet. Close a task with a verified fix to create a work log.')}</section>${isManager()?'<div class="code-note">Manager exports contain client, category, priority, owner and closure time. Detailed issues and fixes are available only to the authorized task owner.</div>':''}`;}
function skillsView(){
  if(isManager())return head('Skills and capacity, side by side.','Use these profiles to distribute work fairly. They are not employee rankings.')+`<div class="full-grid">${state.team.filter(u=>u.role==='consultant').map(u=>{const tasks=active().filter(t=>t.owner===u.id);return `<section class="panel profile-card"><div class="person"><span class="avatar">${initials(u.name)}</span><div><h3>${esc(u.name)}</h3><span class="tiny">${u.on_leave?'On leave':'Available'} · ${tasks.length} active tasks</span></div></div><div>${u.skills.map(s=>`<span class="skill-tag">${esc(s)}</span>`).join('')}</div><div class="progress"><i style="width:${Math.min(100,tasks.length/(state.capacity_limit||8)*100)}%"></i></div><p class="tiny">Capacity guide: ${tasks.length} / ${state.capacity_limit||8} active tasks</p></section>`;}).join('')}</div>`;
  return head('Your skills. Your profile.','Review inferred suggestions and keep your availability up to date.')+`<section class="panel"><div class="panel-head"><h2>${esc(state.user.name)}</h2><span class="badge closed">Employee-owned profile</span></div><div class="panel-body"><label class="form-group">Skills, separated by commas<input id="skills-input" value="${esc(state.user.skills.join(', '))}"></label><p class="muted">Inferred from permitted sample mail: ${state.user.inferred_skills.map(esc).join(', ')||'No suggestions yet'}. These are keyword-based suggestions.</p><label class="check"><input type="checkbox" id="leave-input" ${state.user.on_leave?'checked':''}> I am currently on leave</label><p class="tiny">Leave is entered manually in this demo. Pilot routing always needs manager approval.</p><button class="button" data-action="save-profile">Save profile</button></div></section>`;
}
function auditView(){return head('Every action leaves a trace.','Operational audit without raw email content.')+`<section class="panel"><div class="panel-head"><h2>Recent activity</h2><span class="tiny">Last 30 events</span></div><div class="panel-body">${state.audit.map(a=>`<div class="audit-row"><span><b>${esc(person(a.actor))}</b> · ${esc(a.action.replaceAll('_',' '))}</span><time>${time(a.at)}</time></div>`).reverse().join('')}</div></section>`;}
function importView(){return head('Bring in authorized sample mail.','JSON import demonstrates filtering, deduplication, and multiple actions per thread.')+`<section class="panel"><div class="panel-head"><h2>Sample mailbox import</h2><span class="tiny">Own mailbox only · Up to 200 messages</span></div><div class="panel-body"><p class="muted">Use synthetic data only. Explicit ACTION markers provide stable task identity in the demo extractor.</p><label class="form-group">Messages JSON<textarea id="mail-json" rows="15"></textarea></label><button class="button" data-action="import">Import messages</button></div></section><div class="code-note">Messages with missing classification, excluded categories, or private=true are blocked before extraction. Reclassifying a thread as private removes its tasks and derived records. Body text never acts as an instruction.</div>`;}
function renderLegacy(){
  const nav=[['Overview','◫'],['Handovers','⇄'],['Follow-ups','◷'],['Work log','▤'],[isManager()?'Team skills':'My skills','◇'],...(isManager()?[['Audit trail','◉']]:[['Mail import','↓']])];
  if(!nav.some(([name])=>name===view)) view='Overview';
  $('nav').innerHTML=nav.map(([name,icon])=>`<button data-view="${name}" class="${view===name?'active':''}"><span class="navicon">${icon}</span>${name}</button>`).join('');
  $('crumb').textContent=view;
  const content={Overview:overview,Handovers:handovers,'Follow-ups':nudges,'Work log':resolutions,'My skills':skillsView,'Team skills':skillsView,'Audit trail':auditView,'Mail import':importView};
  $('content').innerHTML=content[view]();
  if(view==='Mail import')$('mail-json').value=JSON.stringify([{mailbox:state.user.id,message_id:'sample-100',thread_id:'sample-thread',classification:'work',private:false,client:'Han River',sender:'operations@hanriver.example',sent_at:state.now,body:'ACTION[ledger]: Review SAP ledger reconciliation\nACTION[report]: Validate P&L report\nUrgent client request; awaiting client confirmation.'}],null,2);
}
async function detail(id){
 const t=state.tasks.find(t=>t.id===id); if(!t)return;
 const controls=isManager()?'':`<p>${esc(t.action)}</p><div class="stack"><label class="form-group">Priority<select id="edit-priority">${['P1','P2','P3','P4'].map(p=>`<option ${p===t.priority?'selected':''}>${p}</option>`).join('')}</select></label><label class="form-group">Status<select id="edit-status">${['In progress','Awaiting client','Needs attention'].map(s=>`<option ${s===t.status?'selected':''}>${s}</option>`).join('')}</select></label></div><button class="button small secondary" data-action="correct" data-id="${id}">Save correction</button>`;
 showModal(`<h2>${esc(t.title)}</h2><div class="stack">${badge(t)}<span class="muted">${esc(person(t.owner))} · ${t.age_hours}h elapsed</span></div><p>${esc(t.summary)}</p><p class="tiny">${Math.round(t.confidence*100)}% demo rules confidence · Task version ${t.version}</p>${t.status!=='Closed'?controls:''}<div class="form-actions">${!isManager()?`<button class="button small secondary" data-action="source" data-id="${id}">View source context</button>`:''}${t.status!=='Closed'?`${!isManager()?`<button class="button small" data-action="draft" data-id="${id}">✦ Suggest reply</button>`:''}<button class="button small secondary" data-action="propose" data-id="${id}">Find backup</button>`:''}</div>${!isManager()&&t.status!=='Closed'?`<label class="form-group">${t.closure_suggested?'Closure suggested · Verify the final resolution':'Confirmed resolution'}<textarea id="fix" placeholder="Describe the verified fix. Confirming closure records this once in your work log."></textarea></label><button class="button small" data-action="close-task" data-id="${id}">Confirm closure & log resolution</button>`:''}<div id="detail-extra" class="section-spacer"></div>`);
}
async function legacyAction(name,id){
 const task=state.tasks.find(t=>t.id===id);
 if(name==='refresh'){await refresh();toast('Workspace refreshed');}
 if(name==='detail')return detail(id);
 if(name==='correct'){await api(`/tasks/${id}`,'PATCH',{version:task.version,priority:$('edit-priority').value,status:$('edit-status').value});await refresh();await detail(id);toast('Correction saved. It will survive resync.');}
 if(name==='source'){const result=await api(`/tasks/${id}/source`);$('detail-extra').innerHTML=`<h3>Authorized source context</h3>${result.notice?`<p class="muted">${esc(result.notice)}</p>`:''}${result.messages.map(m=>`<p class="tiny">${esc(m.sender)} · ${time(m.sent_at)}</p><pre>${esc(m.body)}</pre>`).join('')}`;}
 if(name==='draft'){const result=await api(`/tasks/${id}/drafts`,'POST',{});$('detail-extra').innerHTML=result.match?`<h3>Suggested draft · review required</h3><p class="tiny">${esc(result.notice)}</p><textarea id="reply-draft">${esc(result.body)}</textarea><p class="tiny">Source resolution: ${esc(result.sources.join(', '))}</p><button class="button small secondary" data-action="copy-draft">Copy reviewed draft</button><p class="tiny">Paste and send in Knox after your review.</p>`:'<div class="code-note">No match. There is no authorized resolution for this client and category.</div>';}
 if(name==='copy-draft'){if(navigator.clipboard){await navigator.clipboard.writeText($('reply-draft').value);toast('Draft copied. Review and send in Knox.');}else{ $('reply-draft').select();toast('Draft selected. Use Ctrl+C to copy.');}}
 if(name==='close-task'){await api(`/tasks/${id}/close`,'POST',{version:task.version,fix:$('fix').value});$('modal').close();await refresh();toast('Resolution recorded. Task closed.');}
 if(name==='propose'){const result=await api(`/tasks/${id}/handover`,'POST',{version:task.version});await refresh();if(result.match){$('detail-extra').innerHTML=`<div class="code-note">Proposed backup: <b>${esc(person(result.handover.to))}</b>. Same-team skill match with available capacity. Awaiting manager approval.</div>`;}else toast(result.message);}
 if(name==='approve'){await api(`/handovers/${id}/approve`,'POST',{});await refresh();toast('Handover approved. Context is available to the new owner.');}
 if(name==='tick'){const result=await api('/policy/tick','POST',{});await refresh();toast(`${result.created} new reminders created. Duplicate reminders were skipped.`);}
 if(name==='ack'){await api(`/nudges/${id}/ack`,'POST',{});await refresh();toast('Reminder acknowledged');}
 if(name==='save-profile'){await api('/profile','PATCH',{skills:$('skills-input').value.split(',').map(x=>x.trim()).filter(Boolean),on_leave:$('leave-input').checked});await refresh();toast('Your skills and availability were updated');}
 if(name==='export') {const month=$('export-month').value;if(!month)throw new Error('Choose an export month');window.location.href='/api/resolutions/export?month='+encodeURIComponent(month);}
 if(name==='import'){let messages;try{messages=JSON.parse($('mail-json').value);}catch{throw new Error('Invalid JSON. Check the sample format.');}const result=await api('/mail/import','POST',{messages});await refresh();toast(Object.entries(result).map(([k,v])=>`${v} ${k}`).join(' · '));}
}
document.addEventListener('click',async event=>{
 const button=event.target.closest('[data-view],[data-action],[data-filter]');if(!button)return;
 if(button.dataset.view){view=button.dataset.view;render();return;}
 if(button.dataset.filter){statusFilter=button.dataset.filter;render();return;}
 button.disabled=true;
 try{await action(button.dataset.action,button.dataset.id);}catch(error){toast(error.message);}finally{button.disabled=false;}
});
document.addEventListener('input',event=>{if(event.target.id==='search'){const cursor=event.target.selectionStart;search=event.target.value;render();$('search').focus();$('search').setSelectionRange(cursor,cursor);}});
document.addEventListener('change',event=>{if(event.target.id==='priority-filter'){priorityFilter=event.target.value;render();}});
$('modal-close').addEventListener('click',()=>$('modal').close());

// Connected versions of the two user-supplied dashboard designs.
function renderDashboard(){
 renderLegacy();
 document.body.className=isManager()?'manager-view':'consultant-view';
 $('role-style').href=isManager()?'/manager.css':'/consultant.css';
 $('dashboard-title').textContent=state.user.name+(isManager()?"'s Team Dashboard":"'s Dashboard");
 $('role-label').textContent=isManager()?'Manager view':'Consultant view';
 $('updated').textContent='Updated '+time(state.now);
 document.title=$('dashboard-title').textContent+' — KnoxFlow AI';
}
function simpleKpi(value,label,hl=false){return `<div class="kpi ${hl?'hl':''}"><div class="num">${value}</div><div class="lbl">${label}</div></div>`;}
function priorityClass(t){return ['P1','P2'].includes(t.priority)?'high':t.priority==='P3'?'medium':'low';}
function priorityLabel(t){return ['P1','P2'].includes(t.priority)?'High':t.priority==='P3'?'Medium':'Low';}
function overview(){return isManager()?managerOverview():consultantOverview();}
function consultantOverview(){
 const allTasks=active(),tasks=dashboardTasks();
 const weekStart=new Date(state.now);weekStart.setHours(0,0,0,0);weekStart.setDate(weekStart.getDate()-((weekStart.getDay()+6)%7));
 const week=state.resolutions.filter(r=>new Date(r.closed_at)>=weekStart).length;
 const month=state.resolutions.filter(r=>r.closed_at.slice(0,7)===state.now.slice(0,7)).length;
 return `<div class="kpis">${simpleKpi(allTasks.length,'Active tasks')}${simpleKpi(allTasks.filter(t=>['P1','P2'].includes(t.priority)).length,'High priority',true)}${simpleKpi(week,'Completed this week')}${simpleKpi(month,'Completed this month')}</div><div class="main"><section class="panel"><div class="panel-head"><h2 class="serif">${dashboardFilter.startsWith("completed")?"Completed tasks":"Active tasks"}</h2><p>Your priorities, conversations and next steps in one place.</p></div>${taskControls()}<div class="table-wrap"><table><thead><tr><th>Complete</th><th>Requestor</th><th>Task</th><th>Status</th><th>Priority</th><th>Suggested reply</th></tr></thead><tbody>${tasks.map(t=>{
 const match=state.resolutions.some(r=>r.client===t.client&&r.category===t.category&&r.fix);
 return `<tr class="${t.closure_suggested?'suggest-close':''}"><td class="cb-cell"><input type="checkbox" data-action="complete" data-id="${t.id}" ${t.status==='Closed'?'checked disabled':''} aria-label="Complete ${esc(t.title)}"></td><td class="req">${esc((t.requestor||t.client).split('@')[0])}</td><td>${t.closure_suggested?'<span class="sc-tag">Suggested closure</span><br>':''}<button class="task-name task-link" data-action="detail" data-id="${t.id}">${esc(t.action||t.title)}</button><div class="task-age">Raised ${t.age_hours}h ago</div></td><td><div class="status-wrap"><div class="status">${esc(t.summary)}</div><button class="edit-ic" data-action="edit-status-only" data-id="${t.id}" aria-label="Edit status for ${esc(t.title)}">✎</button></div></td><td><div class="prio-cell"><div class="prio-top"><span class="pill ${priorityClass(t)}">${priorityLabel(t)} · ${t.priority}</span><button class="edit-ic" data-action="edit-priority-only" data-id="${t.id}" aria-label="Edit priority for ${esc(t.title)}">✎</button></div><div class="conf">Rules confidence ${Math.round(t.confidence*100)}%</div></div></td><td><button class="draft ${match?'':'none'}" data-action="reply" data-id="${t.id}">${match?'Draft reply':'No match'}</button></td></tr>`;
 }).join('')}</tbody></table></div>${tasks.length?'':empty('No active tasks. Your confirmed resolutions are in Work log.')}<div class="table-note">Sample mail · Rules confidence is a demo heuristic. Corrections persist across imports; model retraining is deferred.</div></section><aside><div class="skills"><h3 class="serif">Skills Profile</h3><div class="sub">Employee-owned and editable. Inferred suggestions use permitted mail only.</div>${state.user.skills.map(s=>`<div class="skill"><div class="row"><span>${esc(s)}</span><span class="pct">${state.skill_shares?.[s]||0}%</span></div><div class="bar"><i style="width:${state.skill_shares?.[s]||0}%"></i></div></div>`).join('')||'<p>No confirmed skills yet.</p>'}<button class="btn ghost" data-view="My skills">Review / edit skills</button><div class="sub profile-note">Each bar is your share of the team’s tasks in that skill category (active and completed).</div></div><div class="reslog"><h3 class="serif">Resolution Log</h3><div class="sub">${month} confirmed resolutions this month. Resolution parsed from sent mail.</div><input type="month" id="export-month" aria-label="Export month" value="${state.now.slice(0,7)}"><button class="export" data-action="export">Export monthly log</button></div><div class="reslog"><h3 class="serif">Availability</h3><p class="sub">${state.user.on_leave?'Currently on leave':'Available for client work'}</p><button class="btn ghost" data-view="My skills">Update availability</button></div></aside></div>`;
}
function managerOverview(){
 const tasks=active(),visibleTasks=dashboardTasks(),people=state.team.filter(u=>u.role==='consultant');
 const counts=[tasks.filter(t=>['P1','P2'].includes(t.priority)).length,tasks.filter(t=>t.priority==='P3').length,tasks.filter(t=>t.priority==='P4').length];
 const colors=['#c69f7c','#c8bc8b','#a9c48c'];
 let offset=0;const ring=counts.map((n,i)=>{const percent=tasks.length?n/tasks.length*100:0;const circle=`<circle cx="21" cy="21" r="15.9155" fill="transparent" stroke="${colors[i]}" stroke-width="6" stroke-dasharray="${percent} ${100-percent}" stroke-dashoffset="${25-offset}"/>`;offset+=percent;return circle;}).join('');
 const closed=state.tasks.filter(t=>t.status==='Closed').length,completion=state.tasks.length?Math.round(closed/state.tasks.length*100):0;
 const pending=state.handovers.filter(h=>h.status==='Pending');
 const body=people.map(u=>{
  const owned=visibleTasks.filter(t=>t.owner===u.id), high=owned.filter(t=>['P1','P2'].includes(t.priority)).length;
  const total=state.tasks.filter(t=>t.owner===u.id).length,done=state.tasks.filter(t=>t.owner===u.id&&t.status==='Closed').length,progress=total?Math.round(done/total*100):0;
  return `<div class="banner ${u.on_leave?'onleave':''}" data-person="${esc(u.name)}"><div class="banner-head"><span class="member-avatar">${initials(u.name)}</span><div class="name">${esc(u.name)}</div><div class="role">Consultant</div>${u.on_leave?'<span class="leave-tag">On leave</span>':''}</div><div class="banner-body"><div class="stat-row"><span>Tasks</span><b>${owned.length}</b></div><div class="hp n${Math.min(3,high)}">High Priority issues: ${high}</div><div><div class="prog-lbl"><span>Confirmed completion</span><span>${progress}%</span></div><div class="bar"><i class="${high>2?'hot':''}" style="width:${progress}%"></i></div></div><div class="skill-chips">${u.skills.map(s=>`<span class="skill-chip">${esc(s)}</span>`).join('')}</div><div class="task-list">${owned.map((t,i)=>`<div class="t-item ${i>=3?'extra-task':''}" ${i>=3?'hidden':''}><button class="t task-link" data-action="detail" data-id="${t.id}"><span class="dot ${priorityClass(t)==='high'?'h':priorityClass(t)==='medium'?'m':'l'}"></span>${esc(t.title)}</button><div class="s">${esc(t.summary)}</div><div class="issue-age">${lineIcon("clock")}<span>Age · ${issueAge(t)}</span></div></div>`).join('')||'<p class="muted">No active tasks</p>'}</div>${owned.length>3?`<button class="view-more" data-action="expand" data-id="${u.id}">View more (${owned.length-3})</button>`:''}</div></div>`;
 }).join('');
 return `<div class="kpis">${simpleKpi(tasks.length,'Active tasks across team')}${simpleKpi(counts[0],'High priority issues')}${simpleKpi(completion+'%','Confirmed task completion')}${simpleKpi(pending.length,'Handovers awaiting approval')}</div><div class="chart-row"><div class="chart-card"><h3 class="serif">Active tasks by priority</h3><div class="sub">All active tasks across the team</div><div class="chart-flex"><div class="legend">${counts.map((n,i)=>`<div class="leg-row"><span class="leg-dot" style="background:${colors[i]}"></span>${['High','Medium','Low'][i]} priority<b>${n}</b></div>`).join('')}</div><div class="pie-wrap"><svg viewBox="0 0 42 42" role="img" aria-label="Priority distribution"><circle cx="21" cy="21" r="15.9155" fill="transparent" stroke="#E3EBEA" stroke-width="6"/>${ring}</svg><div class="pie-center"><div class="n">${tasks.length}</div><div class="l">tasks</div></div></div></div></div><div class="chart-card"><h3 class="serif">Active tasks by person</h3><div class="sub">Who is holding what right now · counts, not employee scores</div><div class="person-bars">${people.map(u=>{const n=tasks.filter(t=>t.owner===u.id).length;return `<div class="pb-row"><div class="nm">${esc(u.name)}${u.on_leave?'<span class="leave"> · leave</span>':''}</div><div class="pb-bar"><i style="width:${Math.min(100,n/(state.capacity_limit||8)*100)}%"></i></div><div class="ct">${n}</div></div>`;}).join('')}</div></div></div><h2 class="section-title serif">Team workload <small>${people.length} consultants · Client Operations</small></h2>${taskControls()}<div class="team">${body}</div><div class="balance"><div class="bal-top"><h3>Workload balancing · Suggestions <span class="cnt">${pending.length}</span></h3><button class="manual-btn" data-action="manual">Manual workload balancing</button></div>${state.handovers.filter(h=>!h.archived_sample).map((h,i)=>`<div class="sugg ${h.status==='Pending'?'':'decided'}"><div class="idx">${i+1}</div><div class="txt"><b>${esc(person(h.from))}</b> → <b>${esc(person(h.to))}</b>: ${esc(h.title)}<span class="why">${esc(h.reason||"Same-team skill match; availability and capacity rechecked on approval.")}</span></div><div class="acts">${h.status==='Pending'?`<button class="abtn approve" data-action="approve" data-id="${h.id}">Approve</button><button class="abtn reject" data-action="reject" data-id="${h.id}">Reject</button>`:`<span class="decision ${h.status==='Approved'?'ok':'no'}">${esc(h.status)}</span>`}</div></div>`).join('')||'<p>Your team is ready to move. Select manual workload balancing to redistribute an active task.</p>'}<div class="note">Manager-selected transfers take effect immediately. Task age and history stay with the work.</div></div>`;
}
async function connectedAction(name,id){
 if(name==='complete'){const checkbox=document.querySelector(`input[data-id="${id}"]`);if(checkbox)checkbox.checked=false;return detail(id);}
 if(name==='reply'){await detail(id);return legacyAction('draft',id);}
 if(name==='expand'){const personName=person(id);const card=[...document.querySelectorAll('.banner')].find(c=>c.dataset.person===personName);card.querySelectorAll('.extra-task').forEach(t=>t.hidden=!t.hidden);const btn=card.querySelector('.view-more');btn.textContent=card.querySelector('.extra-task').hidden?'View more':'View fewer';return;}
 if(name==='manual'){
   showModal(`<h2>Manual workload balancing</h2><p class="muted">Choose a task and a skill-matched teammate. The server checks eligibility. Review and approve the proposal in the manager dashboard.</p><label class="form-group">Task<select id="manual-task">${active().map(t=>`<option value="${t.id}">${esc(person(t.owner))} · ${esc(t.title)}</option>`).join('')}</select></label><label class="form-group">Backup<select id="manual-person"><option value="">Recommend an eligible backup</option>${state.team.filter(u=>u.role==='consultant').map(u=>`<option value="${u.id}">${esc(u.name)}${u.on_leave?' (on leave)':''}</option>`).join('')}</select></label><button class="button" data-action="manual-propose">Create proposal</button>`);return;
 }
 if(name==='manual-propose'){const tid=$('manual-task').value;const task=state.tasks.find(t=>t.id===tid);if(!task)throw new Error('No active task selected');const result=await api(`/tasks/${tid}/handover`,'POST',{version:task.version,to:$('manual-person').value});if(result.match){$('modal').close();await refresh();toast('Proposal created. Review and approve it below.');}else toast(result.message);return;}
 if(name==='reject'){await api(`/handovers/${id}/reject`,'POST',{});await refresh();toast('Handover rejected. Task owner unchanged.');return;}
 return legacyAction(name,id);
}

let selectedManualTask=null;
function manualBoard(){
 $('modal').classList.add('balancing-modal');
 const selected=state.tasks.find(t=>t.id===selectedManualTask);
 showModal(`<h2>Manual workload balancing</h2><p class="muted">${selected?'Selected: '+esc(selected.title)+'. Select the highlighted recipient to move this task immediately.':'Select an active task from the complete list for any team member, then select its new owner.'}</p><div class="manual-team">${state.team.filter(u=>u.role==='consultant').map(u=>{
 const source=selected&&selected.owner===u.id,recipient=selected&&!source;
 const all=state.tasks.filter(t=>t.owner===u.id);
 return `<section class="manual-member ${source?'dimmed':recipient?'highlight':''}" ${recipient?`data-action="transfer-to" data-id="${u.id}" role="button" tabindex="0" aria-label="Move task to ${esc(u.name)}"`:''}><h3>${esc(u.name)}</h3><p class="tiny">${u.on_leave?'On leave · manager override':'Available'} · ${all.length} total tasks</p>${recipient?'<p class="recipient-hint">Select this person to move task →</p>':''}<div class="manual-task-list">${all.map(t=>`<button class="manual-task ${t.id===selectedManualTask?'selected':''}" data-action="manual-select" data-id="${t.id}" ${t.status==='Closed'?'disabled':''}><b>${esc(t.title)}</b><span>${esc(t.summary)}</span><small>${esc(t.priority)} · ${esc(t.status)} · Age ${issueAge(t)}</small></button>`).join('')||'<p class="muted">No tasks</p>'}</div></section>`;
 }).join('')}</div>`);
}
const closeNormalModal=showModal;
showModal=function(html){if(!html.includes('Manual workload balancing'))$('modal').classList.remove('balancing-modal');closeNormalModal(html);};
async function detail(id){
 const t=state.tasks.find(t=>t.id===id);if(!t)return;
 showModal(`<h2>${esc(t.title)}</h2><p>${esc(t.summary)}</p><div class="stack">${badge(t)}<span class="muted">${t.age_hours}h elapsed · ${esc(person(t.owner))}</span></div>${!isManager()?`<div class="section-spacer"><button class="button" data-action="draft" data-id="${id}">Suggest reply</button></div>`:''}<div id="detail-extra" class="section-spacer"></div>`);
}
async function priorAction(name,id){
 const t=state.tasks.find(t=>t.id===id);
 if(name==='complete'){
  try{await api(`/tasks/${id}/complete`,'POST',{version:t.version});await refresh();toast('Task completed. Resolution is captured from sent mail.');}catch(e){await refresh();throw e;}return;
 }
 if(name==='edit-status-only'){
  showModal(`<h2>Edit status message</h2><label class="form-group">Status message<textarea id="status-message">${esc(t.summary)}</textarea></label><button class="button" data-action="save-status-only" data-id="${id}">Save status</button>`);return;
 }
 if(name==='save-status-only'){await api(`/tasks/${id}`,'PATCH',{version:t.version,summary:$('status-message').value});$('modal').close();await refresh();toast('Status message updated');return;}
 if(name==='edit-priority-only'){
  showModal(`<h2>Edit priority</h2><label class="form-group">Priority<select id="priority-only">${[['P2','High'],['P3','Medium'],['P4','Low']].map(([p,label])=>`<option value="${p}" ${p===(t.priority==='P1'?'P2':t.priority)?'selected':''}>${label}</option>`).join('')}</select></label><button class="button" data-action="save-priority-only" data-id="${id}">Save priority</button>`);return;
 }
 if(name==='save-priority-only'){await api(`/tasks/${id}`,'PATCH',{version:t.version,priority:$('priority-only').value});$('modal').close();await refresh();toast('Priority updated');return;}
 if(name==='manual'){selectedManualTask=null;manualBoard();return;}
 if(name==='manual-select'){if(t.status!=='Closed'){selectedManualTask=id;manualBoard();}return;}
 if(name==='transfer-to'){
  const task=state.tasks.find(t=>t.id===selectedManualTask);if(!task)return;
  await api(`/tasks/${task.id}/transfer`,'POST',{version:task.version,to:id});
  selectedManualTask=null;await refresh();manualBoard();toast('Task moved to '+person(id));return;
 }
 return connectedAction(name,id);
}
document.addEventListener('keydown',event=>{if((event.key==='Enter'||event.key===' ')&&event.target.matches('.manual-member[role="button"]')){event.preventDefault();action('transfer-to',event.target.dataset.id).catch(e=>toast(e.message));}});

function lineIcon(kind){
 const paths={overview:'M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z',handover:'M4 7h15l-4-4m4 4-4 4M20 17H5l4-4m-4 4 4 4',clock:'M12 8v5l3 2M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0',log:'M7 3h10v3H7zM7 5H4v16h16V5h-3M8 11h8M8 15h6',skills:'m12 3 9 9-9 9-9-9 9-9m0 5v8m-4-4h8',mail:'M3 5h18v14H3zM3 5l9 8 9-8',check:'m6 12 4 4 8-8M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0',flag:'M5 21V4m0 0c5-4 9 4 14 0v9c-5 4-9-4-14 0',audit:'M6 3h12v18H6zM9 8h6M9 12h6M9 16h4'};
 return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[kind]||paths.overview}"/></svg>`;
}
function simpleKpi(value,label,hl=false){
 const completed=label.toLowerCase().includes('complet'),priority=label.toLowerCase().includes('priority'),handover=label.toLowerCase().includes('handover');
 const filter=handover?'handovers':priority?'high':completed?(label.includes('week')?'completed-week':label.includes('month')?'completed-month':'completed'):'active';
 const note=completed?'Captured in your work log':priority?'Focus on what matters first':handover?'Ready for manager review':'A connected view of your work';
 return `<button type="button" class="kpi kpi-filter ${hl?'hl':''} ${dashboardFilter===filter?'selected':''}" data-action="dashboard-filter" data-id="${filter}" aria-pressed="${dashboardFilter===filter}"><span class="kpi-art">${lineIcon(completed?'check':priority?'flag':handover?'handover':'overview')}</span><div class="num">${value}</div><div class="lbl">${label}</div><div class="kpi-note">${note}</div></button>`;
}
function renderStudio(){
 renderDashboard();
 $('sidebar-name').textContent=state.user.name;
 $('sidebar-role').textContent=isManager()?'Team manager':'Consultant';
 $('sidebar-avatar').textContent=initials(state.user.name);
 $('role-label').textContent=isManager()?'TEAM OPERATIONS':'PERSONAL WORKSPACE';
 $('dashboard-title').textContent=view==='Overview'?(isManager()?'A clearer view of your team.':'Your day, in focus.'):view;
 $('welcome-description').textContent=isManager()?'The right context. Balanced workloads. A team that moves together.':'All your priorities and conversations, with room to focus.';
 $('updated').textContent=new Date(state.now).toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric',timeZone:'Asia/Kolkata'});
 const keys={Overview:'overview',Handovers:'handover','Follow-ups':'clock','Work log':'log','My skills':'skills','Team skills':'skills','Audit trail':'audit','Mail import':'mail'};
 document.querySelectorAll('#nav button').forEach(button=>{const icon=button.querySelector('.navicon');if(icon)icon.innerHTML=lineIcon(keys[button.dataset.view]);});
 document.title=(isManager()?'Team overview':'My workspace')+' · KnoxFlow AI';
}

let manualMode=false;
function render(){
 renderStudio();
 if(!isManager()){manualMode=false;selectedManualTask=null;}
 if(isManager()&&view==='Overview'){
  const selected=state.tasks.find(t=>t.id===selectedManualTask);
  const cards=document.querySelectorAll('.team .banner');
  cards.forEach(card=>{
   const member=state.team.find(u=>u.name===card.dataset.person);
   if(!member)return;
   if(manualMode){
    const source=selected?.owner===member.id,recipient=!!selected&&!source;
    card.classList.add('inline-manual');
    if(source)card.classList.add('manual-source');
    if(recipient){card.classList.add('manual-recipient');card.dataset.action='transfer-to';card.dataset.id=member.id;card.setAttribute('role','button');card.setAttribute('tabindex','0');card.setAttribute('aria-label','Move selected task to '+member.name);}
    const list=card.querySelector('.task-list');
    list.innerHTML=state.tasks.filter(t=>t.owner===member.id).map(t=>`<button class="inline-task ${t.id===selectedManualTask?'selected':''}" data-action="manual-select" data-id="${t.id}" ${t.status==='Closed'?'disabled':''}><b>${esc(t.title)}</b><span>${esc(t.summary)}</span><small>${esc(t.priority)} · ${esc(t.status)} · Age ${issueAge(t)}</small></button>`).join('')||'<p>No tasks assigned</p>';
    const more=card.querySelector('.view-more');if(more)more.hidden=true;
   }
  });
  const section=document.querySelector('.section-title');
  if(section){
   section.insertAdjacentHTML('afterend',`<div class="inline-balance-toolbar"><div><strong>${manualMode?'Manual balancing is active':'Redistribute work in place'}</strong><p>${manualMode?(selected?'Choose a highlighted teammate to move “'+esc(selected.title)+'”.':'Select an active task below. All tasks, including completed items, are shown.'):'Choose a task and its new owner directly in these team cards.'}</p></div><button class="button ${manualMode?'secondary':''}" data-action="manual">${manualMode?'Exit manual balancing':'Manual workload balancing'}</button></div>`);
  }
  document.querySelectorAll('.manual-btn').forEach(b=>b.textContent=manualMode?'Exit manual balancing':'Manual workload balancing');
 }
}
async function action(name,id){
 if(name==='dashboard-filter'){if(id==='handovers'){view='Handovers';render();return;}dashboardFilter=id;view='Overview';render();return;}
 if(name==='manual'){dashboardFilter='active';view='Overview';manualMode=!manualMode;selectedManualTask=null;render();document.querySelector('.team')?.scrollIntoView({behavior:'smooth',block:'start'});return;}
 if(name==='manual-select'){const t=state.tasks.find(t=>t.id===id);if(t&&t.status!=='Closed'){selectedManualTask=id;render();}return;}
 if(name==='transfer-to'){const t=state.tasks.find(t=>t.id===selectedManualTask);if(!t)return;await api(`/tasks/${t.id}/transfer`,'POST',{version:t.version,to:id});selectedManualTask=null;await refresh();toast('Task moved to '+person(id));return;}
 if(name==='sample-mail'){
  showModal(`<h2>Ingest sample mail</h2><p>Import a synthetic client request. A task is created immediately in the selected consultant’s dashboard and the manager’s team view.</p>${isManager()?`<label class="form-group">Recipient<select id="sample-recipient">${state.team.filter(u=>u.role==='consultant').map(u=>`<option value="${u.id}">${esc(u.name)}</option>`).join('')}</select></label>`:''}<div class="sample-form-grid"><label class="form-group">Client<select id="sample-client"><option>Han River</option><option>Orion</option><option>Maple</option></select></label><label class="form-group">From<input id="sample-sender" value="john.kim@client.example"></label></div><label class="form-group">Subject<input id="sample-subject" value="Urgent SAP access request"></label><label class="form-group">Message<textarea id="sample-body">Hi team,\nPlease review the SAP access issue for our finance team. This is urgent and blocking the monthly close.\nThanks,\nJohn Kim</textarea></label><button class="button" data-action="sample-ingest">Ingest & create task</button>`);return;
 }
 if(name==='sample-ingest'){
  const result=await api('/demo/mail','POST',{mailbox:isManager()?$('sample-recipient').value:state.user.id,client:$('sample-client').value,sender:$('sample-sender').value,subject:$('sample-subject').value,body:$('sample-body').value,request_id:globalThis.crypto?.randomUUID?.()||String(Date.now())});
  if(!result.result.imported)throw new Error('Sample was not imported. Check the fields.');
  $('modal').close();view='Overview';dashboardFilter='active';taskSort='newest';await refresh();toast('Mail ingested. A new task is visible for '+person(result.mailbox)+'.');return;
 }
 return priorAction(name,id);
}
document.addEventListener('keydown',event=>{if((event.key==='Enter'||event.key===' ')&&event.target.matches('.banner.manual-recipient')){event.preventDefault();action('transfer-to',event.target.dataset.id).catch(e=>toast(e.message));}});

function issueAge(task){
 const totalMinutes=Math.max(0,Math.round(Number(task.age_hours||0)*60));
 if(totalMinutes<60)return totalMinutes<1?'Just raised':totalMinutes+'m';
 const hours=Math.floor(totalMinutes/60),days=Math.floor(hours/24),remaining=hours%24;
 return days?days+'d'+(remaining?' '+remaining+'h':''):hours+'h';
}

$('logout').addEventListener('click',async()=>{try{await api('/auth/logout','POST',{});window.location.replace('/login');}catch(error){toast(error.message);}});
(async()=>{try{csrf=(await api('/auth/session')).csrf;await refresh();}catch{window.location.replace('/login');}})();

// Dashboard filters and stable, user-selectable task ordering.
let dashboardFilter='active',taskSort='newest';
function dashboardTasks(){
 const now=new Date(state.now),week=new Date(state.now);week.setHours(0,0,0,0);week.setDate(week.getDate()-((week.getDay()+6)%7));
 return state.tasks.filter(t=>{
  if(dashboardFilter.startsWith('completed')){
   if(t.status!=='Closed')return false;
   if(dashboardFilter==='completed')return true;
   return state.resolutions.some(r=>r.task_id===t.id&&(dashboardFilter==='completed-week'?new Date(r.closed_at)>=week:r.closed_at.slice(0,7)===state.now.slice(0,7)));
  }
  return t.status!=='Closed'&&(dashboardFilter!=='high'||['P1','P2'].includes(t.priority));
 }).sort((a,b)=>{
  let order=0;
  switch(taskSort){
   case 'oldest':order=Number(b.age_hours)-Number(a.age_hours);break;
   case 'priority':order=a.priority.localeCompare(b.priority);break;
   case 'requestor':order=String(a.requestor||a.client).localeCompare(String(b.requestor||b.client));break;
   case 'task':order=String(a.action||a.title).localeCompare(String(b.action||b.title));break;
   case 'status':order=String(a.summary||a.status).localeCompare(String(b.summary||b.status));break;
   case 'confidence':order=Number(b.confidence)-Number(a.confidence);break;
   default:order=Number(a.age_hours)-Number(b.age_hours);
  }
  return order||String(b.created_at||'').localeCompare(String(a.created_at||''))||String(a.id).localeCompare(String(b.id));
 });
}
function taskControls(){return `<div class="task-controls"><span>${dashboardFilter==='high'?'High priority':dashboardFilter.startsWith('completed')?'Completed work':'All active tasks'} · ${dashboardTasks().length} tasks</span><label>Sort by <select id="task-sort" aria-label="Sort tasks">${[['newest','Newest first'],['oldest','Oldest first / age'],['priority','Priority: High to Low'],['requestor','Requestor: A–Z'],['task','Task: A–Z'],['status','Status: A–Z'],['confidence','Confidence: High to Low']].map(([value,label])=>`<option value="${value}" ${taskSort===value?'selected':''}>${label}</option>`).join('')}</select></label><button class="button small secondary" data-action="dashboard-filter" data-id="active">Clear filter</button></div>`;}
document.addEventListener('change',event=>{if(event.target.id==='task-sort'){taskSort=event.target.value;render();}});
