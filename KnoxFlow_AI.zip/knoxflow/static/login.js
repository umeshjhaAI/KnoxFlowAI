'use strict';
let role=location.pathname.endsWith('/manager')?'manager':'consultant';
const $=id=>document.getElementById(id);
let demoAccounts=[];
function selectRole(nextRole){
  role=nextRole;
  for(const name of ['consultant','manager']){
    $(name+'-tab').classList.toggle('active',name===role);
    $(name+'-tab').setAttribute('aria-current',name===role?'page':'false');
  }
  $('login-hint').textContent='Default password: '+(role==='manager'?'Manager@123':'Consultant@123');
  $('login-user').replaceChildren();
  for(const account of demoAccounts.filter(u=>u.role===role)){
    const option=document.createElement('option');option.value=account.username;
    option.textContent=account.name+' ('+account.username+')';$('login-user').append(option);
  }
}
selectRole(role);
(async()=>{try{
  const response=await fetch('/api/auth/accounts');const accounts=await response.json();
  if(!response.ok)throw new Error(accounts.error);
  demoAccounts=accounts;selectRole(role);
  for(const account of demoAccounts){
    const button=document.createElement('button');button.type='button';button.className='demo-login-button';
    const name=document.createElement('strong');name.textContent=account.name;
    const label=document.createElement('span');label.textContent=account.role==='manager'?'Manager':'Consultant';
    button.append(name,label);
    button.addEventListener('click',()=>{
      selectRole(account.role);
      history.replaceState(null,'','/login/'+role);
      $('login-user').value=account.username;
      $('login-password').value=role==='manager'?'Manager@123':'Consultant@123';
      $('login-error').textContent='';
      for(const other of $('demo-login-buttons').children)other.setAttribute('aria-pressed',String(other===button));
      $('demo-login-feedback').textContent=account.name+' selected. Click Sign in to continue.';
      document.querySelector('.login-submit').focus();
    });
    button.setAttribute('aria-pressed','false');$('demo-login-buttons').append(button);
  }
}catch(error){$('login-error').textContent=error.message;}})();
$('login-form').addEventListener('submit',async event=>{event.preventDefault();const button=event.submitter;button.disabled=true;$('login-error').textContent='';try{const response=await fetch('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:$('login-user').value,password:$('login-password').value,role})});const result=await response.json();if(!response.ok)throw new Error(result.error||'Sign-in failed');location.replace('/');}catch(error){$('login-error').textContent=error.message;button.disabled=false;}});
