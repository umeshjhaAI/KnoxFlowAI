"""Transactional local persistence. No mail text is written to the audit log."""
import json
import sqlite3
from contextlib import contextmanager


class Store:
    TABLES = frozenset(('users', 'threads', 'messages', 'tasks', 'resolutions', 'handovers',
                        'nudges', 'drafts', 'audit', 'quarantine', 'credentials'))

    @staticmethod
    def table_name(table):
        if table not in Store.TABLES:
            raise ValueError('Unknown storage table')
        return table

    def __init__(self, path):
        self.path = str(path)
        with self.connect() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS credentials(id TEXT PRIMARY KEY, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS threads(id TEXT PRIMARY KEY, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS tasks(id TEXT PRIMARY KEY, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS resolutions(id TEXT PRIMARY KEY, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS handovers(id TEXT PRIMARY KEY, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS nudges(id TEXT PRIMARY KEY, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS drafts(id TEXT PRIMARY KEY, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS quarantine(id TEXT PRIMARY KEY, data TEXT NOT NULL);
            ''')

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        try:
            db.execute('BEGIN IMMEDIATE')
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def all(db, table):
        table = Store.table_name(table)
        return [json.loads(row['data']) for row in db.execute(f'SELECT data FROM {table} ORDER BY rowid')]

    @staticmethod
    def get(db, table, key):
        table = Store.table_name(table)
        row = db.execute(f'SELECT data FROM {table} WHERE id=?', (key,)).fetchone()
        return json.loads(row['data']) if row else None

    @staticmethod
    def put(db, table, record):
        table = Store.table_name(table)
        db.execute(f'INSERT INTO {table}(id,data) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data',
                   (record['id'], json.dumps(record)))

    @staticmethod
    def delete(db, table, key):
        table = Store.table_name(table)
        db.execute(f'DELETE FROM {table} WHERE id=?', (key,))

    @staticmethod
    def audit(db, actor, action, target, now):
        db.execute('INSERT INTO audit(data) VALUES(?)', (json.dumps(dict(actor=actor, action=action, target=target, at=now)),))
