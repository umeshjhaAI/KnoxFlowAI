import json
import unittest
import test_workflows as fixtures
from auth import Auth, DEFAULT_PASSWORDS
from service import Problem
from store import Store


class PasswordAuth(unittest.TestCase):
    setUp = fixtures.Workflows.setUp
    tearDown = fixtures.Workflows.tearDown

    def test_all_six_accounts_and_roles(self):
        auth=Auth(self.service)
        for account in auth.accounts():
            self.assertEqual(account['id'],auth.authenticate(account['username'],DEFAULT_PASSWORDS[account['role']],account['role']))
        with self.service.store.connect() as db:
            stored=json.dumps(Store.all(db,'credentials'))
        self.assertNotIn('Consultant@123',stored)
        self.assertNotIn('Manager@123',stored)
        self.assertNotIn('digest',json.dumps(self.service.dashboard('alex')))

    def test_wrong_password_and_role_rejected(self):
        auth=Auth(self.service)
        for username,password,role in [('sidhant','wrong','consultant'),('alakh','Manager@123','consultant'),('unknown','wrong','consultant')]:
            with self.assertRaises(Problem) as error:auth.authenticate(username,password,role)
            self.assertEqual(401,error.exception.status)

    def test_repeated_failures_are_throttled(self):
        auth=Auth(self.service)
        for _ in range(5):
            with self.assertRaises(Problem):auth.authenticate('sidhant','wrong')
        with self.assertRaises(Problem) as error:auth.authenticate('sidhant','Consultant@123')
        self.assertEqual(429,error.exception.status)


class LoginHTTP(unittest.TestCase):
    setUp = fixtures.HTTP.setUp
    tearDown = fixtures.HTTP.tearDown
    request = fixtures.HTTP.request

    def test_password_required_and_old_bypass_removed(self):
        self.assertEqual(401,self.request('/api/auth/login','POST',{'username':'sidhant'})[0])
        self.assertEqual(410,self.request('/api/demo/session','POST',{'user_id':'morgan'})[0])
        self.assertEqual(200,self.request('/login/manager')[0])
        self.assertEqual(200,self.request('/login/consultant')[0])

    def test_logout_invalidates_session(self):
        code,body,h=self.request('/api/auth/login','POST',{'username':'alakh','password':'Manager@123'})
        self.assertEqual(200,code)
        headers={'Cookie':h['Set-Cookie'].split(';')[0],'X-CSRF-Token':json.loads(body)['csrf']}
        self.assertEqual(200,self.request('/api/auth/session',headers=headers)[0])
        self.assertEqual(200,self.request('/api/auth/logout','POST',{},headers)[0])
        self.assertEqual(401,self.request('/api/dashboard',headers=headers)[0])
