import unittest
import test_workflows as fixtures


class BalancingExamples(unittest.TestCase):
    setUp = fixtures.Workflows.setUp
    tearDown = fixtures.Workflows.tearDown

    def seed_full_demo(self):
        self.service.seed_logs()
        self.service.seed_scenarios()
        self.service.seed_reference_profile()
        self.service.seed_more_balancing()
        self.service.seed_compact_demo()

    def test_four_proposals_and_all_approvals(self):
        self.seed_full_demo()
        dashboard=self.service.dashboard('morgan')
        extra=[h for h in dashboard['handovers'] if h.get('scenario')=='expanded-balancing-v9']
        self.assertEqual(3,len(extra))
        self.assertEqual(3,len({h['task_id'] for h in extra}))
        self.assertEqual(4,sum(h['status']=='Pending' for h in dashboard['handovers']))
        original_ages={t['id']:t['created_at'] for t in dashboard['tasks']}
        for h in dashboard['handovers']:
            approved=self.service.approve('morgan',h['id'])
            self.assertEqual('Approved',approved['status'])
        refreshed=self.service.dashboard('morgan')
        for h in refreshed['handovers']:
            task=next(t for t in refreshed['tasks'] if t['id']==h['task_id'])
            self.assertEqual(h['to'],task['owner'])
            self.assertEqual(original_ages[task['id']],task['created_at'])
        self.assertTrue(all(sum(t['owner']==u['id'] and t['status']!='Closed' for t in refreshed['tasks'])<=16
                            for u in refreshed['team'] if u['id'] in ('priya','pushpak','sarita')))

    def test_restart_preserves_approval_rejection_and_no_duplicates(self):
        self.seed_full_demo()
        rows=[h for h in self.service.dashboard('morgan')['handovers'] if h.get('scenario')=='expanded-balancing-v9']
        self.service.approve('morgan',rows[0]['id'])
        self.service.reject('morgan',rows[1]['id'])
        self.service.seed_more_balancing()
        self.service.seed_compact_demo()
        after=[h for h in self.service.dashboard('morgan')['handovers'] if h.get('scenario')=='expanded-balancing-v9']
        self.assertEqual(3,len(after))
        states={h['id']:h['status'] for h in after}
        self.assertEqual('Approved',states[rows[0]['id']])
        self.assertEqual('Rejected',states[rows[1]['id']])

    def test_reduced_tasks_and_sidhant_suggested_closure(self):
        self.service.seed_logs()
        self.service.seed_scenarios()
        self.service.seed_reference_profile()
        self.service.seed_more_balancing()
        before=self.service.dashboard('morgan')
        counts={uid:sum(t['owner']==uid for t in before['tasks']) for uid in ('alex','priya','daniel','sarita','pushpak')}
        self.service.seed_compact_demo()
        after=self.service.dashboard('morgan')
        for uid, count in counts.items():
            self.assertEqual(count-2,sum(t['owner']==uid for t in after['tasks']))
        task=next(t for t in self.service.dashboard('alex')['tasks'] if t['action']=='T-code requirement - FICO')
        self.assertEqual('Instructions shared with Ms Lee',task['summary'])
        self.assertTrue(task['closure_suggested'])
        self.assertNotEqual('Closed',task['status'])
        self.service.seed_compact_demo()
        self.assertEqual(len(after['tasks']),len(self.service.dashboard('morgan')['tasks']))
