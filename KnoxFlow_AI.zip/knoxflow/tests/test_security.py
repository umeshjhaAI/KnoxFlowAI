"""Security and robustness regressions using synthetic data and temporary storage."""
import copy
import json
import socket
import unittest
from pathlib import Path
import test_workflows as fixtures
from service import Problem
from store import Store
from server import make_handler


class DomainSecurity(unittest.TestCase):
    setUp = fixtures.Workflows.setUp
    tearDown = fixtures.Workflows.tearDown
    mail = fixtures.Workflows.mail
    assertProblem = fixtures.Workflows.assertProblem

    def test_unknown_table_is_rejected(self):
        with self.service.store.connect() as db:
            with self.assertRaises(ValueError):
                Store.all(db, 'tasks; DROP TABLE users;--')
            self.assertTrue(Store.all(db, 'users'))

    def test_sql_values_are_bound(self):
        with self.service.store.connect() as db:
            self.assertIsNone(Store.get(db, 'tasks', "x' OR 1=1--"))
            self.assertTrue(Store.all(db, 'tasks'))

    def test_transaction_rolls_back_all_writes(self):
        with self.assertRaises(RuntimeError):
            with self.service.store.connect() as db:
                Store.put(db, 'quarantine', {'id': 'rollback', 'reason': 'test'})
                raise RuntimeError('forced failure')
        with self.service.store.connect() as db:
            self.assertIsNone(Store.get(db, 'quarantine', 'rollback'))

    def test_invalid_client_is_quarantined_not_crash(self):
        result = self.service.import_mail('alex', [self.mail(client={'bad': 'type'})])
        self.assertEqual(1, result['quarantined'])

    def test_invalid_direction_cannot_supply_resolution(self):
        result = self.service.import_mail('alex', [self.mail(direction='forged')])
        self.assertEqual(1, result['quarantined'])

    def test_invalid_identifier_is_safe_error(self):
        self.assertProblem(400, self.service.dashboard, {'id': 'alex'})

    def test_unknown_patch_fields_cannot_change_owner(self):
        self.assertProblem(400, self.service.patch_task, 'alex', self.task['id'],
                           {'version': self.task['version'], 'owner': 'priya'})

    def test_handover_summary_does_not_leak_free_text(self):
        secret = 'PRIVATE-CONTEXT-SENTINEL'
        task = self.service.patch_task('alex', self.task['id'], {'version': self.task['version'], 'summary': secret})
        self.service.propose('alex', task['id'], {'version': task['version']})
        self.assertNotIn(secret, json.dumps(self.service.dashboard('morgan')))

    def test_cross_team_access_and_manual_transfer_denied(self):
        with self.service.store.connect() as db:
            outsider = copy.deepcopy(Store.get(db, 'users', 'priya'))
            outsider.update(id='outsider', team='Other Team')
            Store.put(db, 'users', outsider)
        self.assertProblem(404, self.service.source, 'outsider', self.task['id'])
        self.assertProblem(403, self.service.transfer, 'morgan', self.task['id'],
                           {'version': self.task['version'], 'to': 'outsider'})
        self.assertProblem(403, self.service.sample_mail, 'morgan',
                           {'mailbox': 'outsider', 'subject': 'Test', 'body': 'Test'})

    def test_sample_mail_request_id_is_idempotent(self):
        sample = {'mailbox': 'priya', 'request_id': 'fixed-request', 'client': 'Han River',
                  'sender': 'client@example.test', 'subject': 'Urgent SAP access review', 'body': 'Please review.'}
        first = self.service.sample_mail('morgan', sample)
        second = self.service.sample_mail('morgan', sample)
        self.assertEqual(1, first['result']['imported'])
        self.assertEqual(1, second['result']['duplicate'])

    def test_consultant_sample_cannot_impersonate_mailbox(self):
        sample = {'mailbox': 'priya', 'client': 'Han River', 'sender': 'client@example.test',
                  'subject': 'SAP review', 'body': 'Please review.'}
        self.assertEqual('alex', self.service.sample_mail('alex', sample)['mailbox'])

    def test_no_content_in_audit_or_quarantine(self):
        marker = 'MAIL-BODY-SECRET-123'
        self.service.import_mail('alex', [self.mail(body='ACTION[one]: SAP review\n'+marker)])
        with self.service.store.connect() as db:
            self.assertNotIn(marker, json.dumps(Store.all(db, 'audit')+Store.all(db, 'quarantine')))

    def test_multi_action_resolution_does_not_mix_fixes(self):
        self.service.import_mail('alex', [self.mail(direction='sent', body='ACTION[one]: SAP review\nACTION[two]: Access review\nRESOLUTION[one]: First fix\nRESOLUTION[two]: Second fix')])
        tasks = self.service.dashboard('alex')['tasks'][-2:]
        fixes = [self.service.complete('alex', t['id'], {'version': t['version']})['fix'] for t in tasks]
        self.assertEqual(['First fix', 'Second fix'], fixes)

    def test_demo_scenario_is_not_recreated_after_approval(self):
        self.service.seed_logs()
        self.service.seed_scenarios()
        h = next(h for h in self.service.dashboard('morgan')['handovers'] if h['status']=='Pending')
        self.service.approve('morgan', h['id'])
        self.service.seed_scenarios()
        self.assertFalse(any(h['status']=='Pending' for h in self.service.dashboard('morgan')['handovers']))

    def test_reference_skills_preserve_employee_edits(self):
        self.service.seed_reference_profile()
        self.assertIn('SAP Asset Management', self.service.dashboard('alex')['user']['skills'])
        self.service.skills('alex', {'skills': ['Reporting']})
        self.service.seed_reference_profile()
        self.assertEqual(['Reporting'], self.service.dashboard('alex')['user']['skills'])


class HTTPSecurity(unittest.TestCase):
    setUp = fixtures.HTTP.setUp
    tearDown = fixtures.HTTP.tearDown
    request = fixtures.HTTP.request

    def login(self, uid='alex'):
        code, body, headers = self.request('/api/auth/login', 'POST', {'username':uid,'password':'Manager@123' if uid=='morgan' else 'Consultant@123'})
        self.assertEqual(200, code)
        return {'Cookie': headers['Set-Cookie'].split(';')[0], 'X-CSRF-Token': json.loads(body)['csrf']}

    def test_security_headers_and_cookie_attributes(self):
        _, _, headers = self.request('/')
        for header in ('Content-Security-Policy', 'X-Content-Type-Options', 'X-Frame-Options', 'Permissions-Policy'):
            self.assertIn(header, headers)
        self.assertNotIn('Python', headers['Server'])
        _, _, headers = self.request('/api/auth/login', 'POST', {'username':'sidhant','password':'Consultant@123'})
        self.assertIn('HttpOnly', headers['Set-Cookie'])
        self.assertIn('SameSite=Strict', headers['Set-Cookie'])

    def test_cross_site_without_origin_denied(self):
        self.assertEqual(403, self.request('/api/auth/login', 'POST', {'username':'sidhant','password':'Consultant@123'}, {'Sec-Fetch-Site':'cross-site'})[0])

    def test_demo_endpoints_can_be_disabled(self):
        self.server.RequestHandlerClass = make_handler(self.service, allow_demo_login=False)
        self.assertEqual(403, self.request('/api/demo/users')[0])
        self.assertEqual(403, self.request('/api/auth/login', 'POST', {'username':'alakh','password':'Manager@123'})[0])

    def test_no_path_traversal_static_files(self):
        headers = self.login()
        self.assertEqual(404, self.request('/../config.json', headers=headers)[0])
        self.assertEqual(404, self.request('/%2e%2e/config.json', headers=headers)[0])

    def test_manager_cannot_read_or_modify_mail_task(self):
        headers = self.login('morgan')
        tid = self.task['id']
        self.assertEqual(403, self.request(f'/api/tasks/{tid}/source', headers=headers)[0])
        self.assertEqual(403, self.request(f'/api/tasks/{tid}/drafts', 'POST', {}, headers)[0])
        self.assertEqual(403, self.request(f'/api/tasks/{tid}', 'PATCH', {'version':1,'priority':'P4'}, headers)[0])

    def test_end_to_end_sample_complete_and_export(self):
        headers = self.login()
        sample = {'client':'Han River','sender':'john@example.test','subject':'Urgent SAP review','body':'Please review.'}
        self.assertEqual(200, self.request('/api/demo/mail','POST',sample,headers)[0])
        _, body, _ = self.request('/api/dashboard', headers=headers)
        task = json.loads(body)['tasks'][-1]
        self.assertEqual(200,self.request(f'/api/tasks/{task["id"]}/complete','POST',{'version':task['version']},headers)[0])
        self.assertEqual(200,self.request('/api/resolutions/export?month=2026-10',headers=headers)[0])
        self.assertEqual(400,self.request('/api/resolutions/export?month=bad',headers=headers)[0])

    def test_reassignment_and_approval_routes(self):
        headers = self.login('morgan')
        t = self.task
        code, body, _ = self.request(f'/api/tasks/{t["id"]}/handover','POST',{'version':t['version']},headers)
        self.assertEqual(200,code)
        hid = json.loads(body)['handover']['id']
        self.assertEqual(200,self.request(f'/api/handovers/{hid}/approve','POST',{},headers)[0])
        t = self.service.dashboard('priya')['tasks'][-1]
        self.assertEqual(200,self.request(f'/api/tasks/{t["id"]}/transfer','POST',{'version':t['version'],'to':'alex'},headers)[0])

    def test_large_body_wrong_type_and_non_object_rejected(self):
        # Declare an oversized body without uploading it. An early HTTP reject
        # is allowed to close before a client has finished sending a large body.
        with socket.create_connection(('127.0.0.1', self.server.server_port), timeout=5) as sock:
            sock.sendall((f'POST /api/auth/login HTTP/1.1\r\nHost: 127.0.0.1:{self.server.server_port}\r\n'
                          'Content-Type: application/json\r\nContent-Length: 1000001\r\n\r\n').encode())
            self.assertIn(b' 413 ', sock.recv(4096).split(b'\r\n')[0])
        self.assertEqual(415,self.request('/api/auth/login','POST',{}, {'Content-Type':'text/plain'})[0])
        self.assertEqual(400,self.request('/api/auth/login','POST',[])[0])

    def test_non_finite_json_rejected(self):
        self.assertEqual(400,self.request('/api/auth/login','POST',{'value':float('nan')})[0])
