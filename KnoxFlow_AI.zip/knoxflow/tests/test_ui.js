// Lightweight DOM-adapter tests. These are not browser rendering/screenshot tests.
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const elements = {};
function element() {
  return {textContent:'',innerHTML:'',style:{},open:false,classList:{add(){},remove(){}},
    addEventListener(){},showModal(){this.open=true;},close(){this.open=false;}};
}
const context = {document:{getElementById(id){return elements[id]??=element();},querySelectorAll(){return [];},
  querySelector(){return null;},addEventListener(){},body:{}},
  fetch:()=>new Promise(()=>{}),setTimeout,clearTimeout,console,navigator:{},window:{}};
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(__dirname,'../static/app.js'),'utf8'),context);
const team=[{id:'alex',name:'Sidhant Nayak',role:'consultant',skills:['SAP'],inferred_skills:[],on_leave:false},
  {id:'morgan',name:'Alakh Singh',role:'manager',skills:[],on_leave:false}];
const task={id:'t',owner:'alex',title:'SAP issue',action:'Untrusted <script>alert(1)</script>',
  requestor:'john@example.test',client:'Han River',category:'SAP',summary:'Review pending',priority:'P2',
  status:'In progress',age_hours:49,confidence:0.72,version:1};
context.fixture={user:team[0],team,tasks:[task],resolutions:[],handovers:[],audit:[],nudges:[],
  skill_shares:{SAP:75},now:'2026-10-27T09:00:00+00:00'};
let checks=0;
function test(name, callback){callback();checks++;console.log('PASS '+name);}
vm.runInContext('state=fixture;render()',context);
test('HTML text is escaped',()=>assert(!elements.content.innerHTML.includes('<script>alert')));
test('Skill percentage is shown',()=>assert(elements.content.innerHTML.includes('75%')));
vm.runInContext('action("edit-status-only","t")',context);
test('Status editor contains no priority field',()=>{
  assert(elements['modal-content'].innerHTML.includes('status-message'));
  assert(!elements['modal-content'].innerHTML.includes('priority-only'));
});
vm.runInContext('action("edit-priority-only","t")',context);
test('Priority editor contains only High/Medium/Low options',()=>{
  const html=elements['modal-content'].innerHTML;
  assert(html.includes('High')&&html.includes('Medium')&&html.includes('Low'));
  assert(!html.includes('status-message'));
});
elements.modal.close();context.fixture.user=team[1];
vm.runInContext('state=fixture;render();action("manual")',context);
test('Manual balancing is in-place, with no dialog',()=>assert.equal(elements.modal.open,false));
test('Manager task age is visible',()=>assert(elements.content.innerHTML.includes('Age · 2d 1h')));
vm.runInContext('action("sample-mail")',context);
test('Sample ingestion dialog has submit action',()=>assert(elements['modal-content'].innerHTML.includes('sample-ingest')));
test('Age formatter handles minutes',()=>assert.equal(vm.runInContext('issueAge({age_hours:0.5})',context),'30m'));
context.fixture.user=team[0];task.closure_suggested=true;task.summary='Instructions shared with Ms Lee';
vm.runInContext('state=fixture;render()',context);
test('Suggested closure row has status, badge and highlight class',()=>{assert(elements.content.innerHTML.includes('Instructions shared with Ms Lee'));assert(elements.content.innerHTML.includes('Suggested closure'));assert(elements.content.innerHTML.includes('class="suggest-close"'));});
console.log(checks+' UI adapter checks passed.');

const newer={...task,id:'new',title:'Newest issue',action:'Newest issue',priority:'P4',age_hours:0.1,created_at:'2026-10-27T08:54:00Z'};
const closed={...task,id:'done',status:'Closed'};
context.fixture.tasks=[task,newer,closed];
context.fixture.resolutions=[{task_id:'done',closed_at:'2026-10-27T08:00:00Z'}];
vm.runInContext("state=fixture;dashboardFilter='active';taskSort='newest'",context);
test('Newest ingestion sorts ahead of older high priority work',()=>assert.equal(vm.runInContext('dashboardTasks()[0].id',context),'new'));
vm.runInContext("taskSort='priority'",context);
test('Priority sorting puts urgent work first',()=>assert.equal(vm.runInContext('dashboardTasks()[0].id',context),'t'));
vm.runInContext("dashboardFilter='high'",context);
test('High priority card excludes closed and low priority tasks',()=>assert.equal(vm.runInContext('dashboardTasks().map(t=>t.id).join()',context),'t'));
vm.runInContext("dashboardFilter='completed-week'",context);
test('Completed week filter uses resolution evidence',()=>assert.equal(vm.runInContext('dashboardTasks()[0].id',context),'done'));
vm.runInContext("action('dashboard-filter','active');taskSort='oldest'",context);
test('Clear filter restores active tasks and oldest sort works',()=>assert.equal(vm.runInContext('dashboardTasks().map(t=>t.id).join()',context),'t,new'));
test('Summary cards are accessible filter buttons',()=>assert(vm.runInContext("simpleKpi(2,'High priority')",context).includes('data-action="dashboard-filter"')));
console.log(checks+' total UI adapter checks passed.');
