"""Run real regression tests with standard-library line coverage; no pip install."""
import json
import py_compile
import sys
import threading
import trace
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests'))


def main():
    # Absolute code filenames keep trace attribution consistent after a user has
    # compiled the same source from a different working directory.
    for name in ('service.py', 'server.py', 'store.py', 'auth.py'):
        py_compile.compile(str(ROOT / name), doraise=True)
    tracer = trace.Trace(count=True, trace=False)
    measured_paths = {str(ROOT / name) for name in ('service.py', 'server.py', 'store.py', 'auth.py')}
    def project_trace(frame, event, arg):
        # Match full paths. trace's basename ignore cache confuses our server.py
        # with the standard-library http/server.py when ignoredirs is used.
        if event == 'call' and frame.f_code.co_filename in measured_paths:
            return tracer.localtrace_count
        return None
    tracer.globaltrace = project_trace
    def run():
        suite = unittest.defaultTestLoader.discover(str(ROOT / 'tests'))
        return unittest.TextTestRunner(verbosity=2).run(suite)
    threading.settrace(tracer.globaltrace)
    try:
        result = tracer.runfunc(run)
    finally:
        threading.settrace(None)
    counts = tracer.results().counts
    modules = {}
    for name in ('service.py', 'server.py', 'store.py', 'auth.py'):
        path = ROOT / name
        # Same executable-line analysis used by Python's built-in trace report.
        executable = set(trace._find_executable_linenos(str(path)))
        covered = {line for (filename, line), count in counts.items() if Path(filename).resolve() == path and count}
        hit = len(executable & covered)
        modules[name] = {'covered_lines': hit, 'executable_lines': len(executable),
                         'line_coverage_percent': round(100 * hit / len(executable), 2)}
    hit = sum(m['covered_lines'] for m in modules.values())
    total = sum(m['executable_lines'] for m in modules.values())
    percent = round(100 * hit / total, 2)
    report = dict(tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                  coverage_type='executable line coverage, not branch coverage',
                  modules=modules, total_line_coverage_percent=percent, minimum_percent=80)
    output = ROOT / 'build' / 'coverage'
    output.mkdir(parents=True, exist_ok=True)
    (output / 'summary.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))
    return 0 if result.wasSuccessful() and percent >= 80 else 1


if __name__ == '__main__':
    raise SystemExit(main())
