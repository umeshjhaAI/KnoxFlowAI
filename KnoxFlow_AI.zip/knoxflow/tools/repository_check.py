"""Offline repository checks. Heuristic secret detection is not a security audit."""
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PATTERNS = [re.compile(r'AKIA[0-9A-Z]{16}'), re.compile(r'sk-[A-Za-z0-9_-]{32,}'),
            re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE' + r' KEY-----')]


def main():
    git = subprocess.run(['git', 'ls-files', '--cached', '--others', '--exclude-standard'],
                         cwd=ROOT, capture_output=True, text=True)
    if git.returncode:
        print('Git metadata unavailable. Run git init/add first, or clone the supplied bundle.')
        return 1
    errors = []
    paths = sorted(set(git.stdout.splitlines()))
    for name in paths:
        path = Path(name)
        if any(p in ('__pycache__', 'node_modules', 'build', '.venv') for p in path.parts) or path.suffix in ('.pyc', '.zip', '.bundle', '.sqlite3') or (path.name.startswith('.env') and path.name != '.env.example'):
            errors.append(f'Generated/private artifact selected for version control: {name}')
        target = ROOT / path
        if not target.is_file():
            continue
        try:
            content = target.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            continue
        if any(pattern.search(content) for pattern in PATTERNS):
            errors.append(f'Potential secret found: {name} (value suppressed)')
    for command in (['git', 'diff', '--check'], ['git', 'diff', '--cached', '--check']):
        check = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        if check.returncode:
            errors.append(check.stdout.strip())
    for error in errors:
        print(error)
    print(f'Checked {len(paths)} selected source files; {len(errors)} issue(s).')
    return 1 if errors else 0


if __name__ == '__main__':
    raise SystemExit(main())
